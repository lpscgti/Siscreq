/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.ModeloTipoUnd;
import visual.FormPrincipal;

/**
 *
 * @author linde
 */
public class ControleTipoUnd {
    //Declara importações;
    ConectaBanco c_db = new ConectaBanco();
    ModeloTipoUnd mod_tipo = new ModeloTipoUnd();
    ControleUniversal ctrl_uni = new ControleUniversal();
    
    //Declara variaveis;
   public int Cod_tipo;
   String novo_reg, sql;
   public String menssagem_erro ,mensagem_erro_comp;
   PreparedStatement pst;
   public boolean novo_cad = false;
    public Date Data = new Date();
    public java.sql.Date Dagora;
   
   
   public void NovoRegistro(){
    
       c_db.conecta();
       sql = "insert into tipo_und (tipo, data_cad, cad_por) values (?,?,?)";
       novo_reg = "tipoxx";
            try {
                pst = c_db.conn.prepareStatement(sql);
                pst.setString(1, novo_reg);
                pst.setDate(2, new java.sql.Date(Data.getTime()));
                pst.setString(3, FormPrincipal.UsuarioLogado);
                pst.execute();
            } catch (SQLException ex) {
                menssagem_erro = ex.toString();
            }
            try {
                sql = "select * from tipo_und where tipo='"+novo_reg+"'";
                c_db.executaSQL(sql);
                c_db.rs.first();
                Cod_tipo = c_db.rs.getInt("codigo");
            } catch (SQLException ex) {
                menssagem_erro = ex.toString();
            }
        novo_cad=true;
        c_db.desconecta();
       
   }
   
   public boolean SalvaRegistro(ModeloTipoUnd mod, boolean new_cad){
       
       c_db.conecta();
       if (new_cad==true){
            
            try{
                sql = "update tipo_und set tipo=? where codigo=?";
                pst = c_db.conn.prepareStatement(sql);
                pst.setString(1, mod.getTipo());
                pst.setInt(2, Cod_tipo);
                int n=pst.executeUpdate();
                     if (n!=0){
                         return true;
                     }else{
                         return false;
                     }
            } catch (SQLException ex) {
             menssagem_erro = ex.toString();
            }
            
       }else{
           
           try{
                sql = "update tipo_und set tipo=?, data_mod=?, mod_por=? where codigo=?";
                pst = c_db.conn.prepareStatement(sql);
                pst.setString(1, mod.getTipo());
                pst.setDate(2, mod.getData_mod());
                pst.setString(3, FormPrincipal.UsuarioLogado);
                pst.setInt(4, Cod_tipo);
                int n=pst.executeUpdate();
                     if (n!=0){
                         return true;
                     }else{
                         return false;
                     }
           } catch (SQLException ex){
               menssagem_erro = ex.toString();
           }
       }
       c_db.desconecta();
       return false;
   }
   
   public void ExcluiRegistro(ModeloTipoUnd mod){
        c_db.conecta();
        sql = "delete from tipo_und where codigo=?";
        try {
            PreparedStatement pst = c_db.conn.prepareStatement(sql);
            pst.setInt(1, mod.getCodigo());
            pst.execute();
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        c_db.desconecta();
    }
   
}
