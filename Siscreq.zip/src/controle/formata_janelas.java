/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com Pereira
 */
public class formata_janelas {
    obter_arquivo_conf o_ac = new obter_arquivo_conf();
    int TamTelaAltura, TamTelaLargura;
    int TamFormPrinc_A, TamFormPrinc_L;
    
    public void aplicavisual(){
        
        
        try {
            
            o_ac.ObterInfoConfig();
                String num = o_ac.tema_visual;
                
            
                if (num.equals("0")){

                    FlatLightLaf.install();
                    UIManager.setLookAndFeel(new FlatLightLaf());

                } else if (num.equals("1")){

                    FlatIntelliJLaf.install();
                    UIManager.setLookAndFeel(new FlatIntelliJLaf());

                } else if (num.equals("2")){

                    FlatDarkLaf.install();
                    UIManager.setLookAndFeel(new FlatDarkLaf());

                } else if (num.equals("3")){
                    
                    FlatDarculaLaf.install();
                    UIManager.setLookAndFeel(new FlatDarculaLaf());

                } else if (num.equals("4")){

                    UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
                    

                }else{

                    FlatLightLaf.install();
                    UIManager.setLookAndFeel(new FlatLightLaf());

                }
                
        
        } catch (IOException ex) {
            Logger.getLogger(formata_janelas.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(formata_janelas.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(formata_janelas.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(formata_janelas.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(formata_janelas.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }
    
    public void RedimensionaAreaTrabalho(JDesktopPane desktop, JFrame frm){
        
        if (frm.getExtendedState()==JFrame.MAXIMIZED_BOTH){
        
            Dimension TamTela = Toolkit.getDefaultToolkit().getScreenSize(); //Código para obter o tamenho de altura e largura da tela.
            TamTelaAltura = (int) TamTela.getHeight();//Armazena a altura
            TamTelaLargura = (int) TamTela.getWidth();//Armazena a largura
//            desktop.setLocation(90, 0);
            desktop.setSize(TamTelaLargura, TamTelaAltura-115);
            desktop.setBorder(new plano_fundo_janelaprincipal(desktop));
//            JOptionPane.showMessageDialog(desktop, TamTelaAltura-115);
        
        }if (frm.getExtendedState()==JFrame.NORMAL){
//            
            desktop.setLocation(90, 0);
            desktop.setSize(940, 656);
            desktop.setBorder(new plano_fundo_janelaprincipal(desktop));
//    //        JOptionPane.showMessageDialog(desktop, TamFormPrinc_A+" A e L"+TamFormPrinc_L);
//            
        }
         
    }
        
    
    public void RedimensionaBarraFerramentas(JToolBar barra, JFrame frm){
        
        if (frm.getExtendedState()==JFrame.MAXIMIZED_BOTH){
        
            Dimension TamTela = Toolkit.getDefaultToolkit().getScreenSize(); //Código para obter o tamenho de altura e largura da tela.
            TamTelaAltura = (int) TamTela.getHeight();//Armazena a altura
            int TamTAltura = TamTelaAltura-115;
            TamTelaLargura = (int) TamTela.getWidth();//Armazena a largura
            barra.setSize(90, TamTAltura);
            barra.setFloatable(false);
        
        }if (frm.getExtendedState()==JFrame.NORMAL){
            barra.setLocation(0,0);
            barra.setSize(90, 656);
            barra.setFloatable(false);
            
        }
        
        
    }
    
    
    public void StatusBar(javax.swing.JFrame janela, String Usuario, String Empresa){
        
    //Three panels that are to added to the JFrame
    JPanel statusBar = new JPanel();
    final JLabel welcomedate;
    JLabel msg;
 
    Date dthojeHora = new Date();
    SimpleDateFormat DtFormatHora = new SimpleDateFormat("HH");
    String HoraAgora = (DtFormatHora.format(dthojeHora));
    int HorAgo = Integer.parseInt(HoraAgora);
    String MensagemSaudacao = null;
        
    if (HorAgo<12){
        MensagemSaudacao = "Bom Dia";
    }else if (HorAgo>18){
        MensagemSaudacao = "Boa Noite";
    }else {
        MensagemSaudacao = "Boa Tarde";
    }
        
    //Creating the StatusBar.
        janela.setLayout(new BorderLayout());//frame layout
        
        msg = new JLabel(" " + MensagemSaudacao+", "+Usuario+"    |   "+Empresa, JLabel.LEFT);
        msg.setForeground(Color.black);
//        msg.setToolTipText("Nossa saudação, seu nome de usuário e o nome de sua empresa.");
        welcomedate = new JLabel();
        welcomedate.setOpaque(true);//to set the color for jlabel
        welcomedate.setBackground(Color.white);
        welcomedate.setForeground(Color.black);
        statusBar.setLayout(new BorderLayout());
        statusBar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        statusBar.setBackground(Color.WHITE);
        statusBar.add(msg, BorderLayout.WEST);
        statusBar.add(welcomedate, BorderLayout.EAST);
        janela.add("South", statusBar);
        
    //display date time to status bar
        javax.swing.Timer timee = new javax.swing.Timer(1000, new ActionListener() {
 
            @Override
            public void actionPerformed(ActionEvent e) {
                java.util.Date now = new java.util.Date();
                String ss = DateFormat.getDateTimeInstance().format(now);
                welcomedate.setText(ss);
                welcomedate.setToolTipText("Bem-vindo, hojé é " + ss);
 
            }
        });
        timee.start();
        
    }
            
    public void AbreNovaJanelaInterna(JInternalFrame jif, JDesktopPane desktop){
               
                String local_img_icone;
                Path caminhoTXT;
                int lDesk = desktop.getWidth();  
                int aDesk = desktop.getHeight();  
                int lIFrame = jif.getWidth();  
                int aIFrame = jif.getHeight();  
                jif.setLocation(lDesk / 2 - lIFrame / 2, aDesk / 2 - (aIFrame / 2));
                caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
                local_img_icone = caminhoTXT+"/"+"icone_16x16.png";
                jif.setFrameIcon(new ImageIcon(local_img_icone));
//                jif.setFrameIcon(new ImageIcon(jif.getClass().getResource("/imagens/gta_control_icone_16X16.png")));
                desktop.add(jif); //adiciona na tela
                jif.setVisible(true); // seta visivel
    }
    
    
    public void AbreNovaJanela(JFrame jf){
        
        String local_img_icone;
        Path caminhoTXT;
        caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        local_img_icone = caminhoTXT+"/"+"icone_16x16.png";
        jf.setIconImage(Toolkit.getDefaultToolkit().getImage(local_img_icone));
        jf.setVisible(true);
                
    }

    
    
}
