/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com Pereira
 */
public class gera_auditoria {
    
    //declara importações;
    ConectaBanco c_db = new ConectaBanco();
    PreparedStatement pst;
    
    //declara variaveis;
    String sql, mensagem;
    public Date Data = new Date();
    public java.sql.Date DataSQL;
    
    
    
    public void g_auditoria(String acao, String situacao, String usuario, String tabela, boolean user_inv, String user_invoc){
        
        c_db.conecta();
        DataSQL = new java.sql.Date(Data.getTime());
        sql = "insert into auditoria (data, acao, situacao, mensagem, usuario) values (?,?,?,?,?)";
        if (user_inv==true){
            mensagem = "solicitação do usuário "+usuario+" para realizar "+acao+" na tabela "+tabela+" através da validação do usuário "+user_invoc+" - "+situacao+".";
        }else{
            mensagem = "solicitação do usuário "+usuario+" para realizar "+acao+" na tabela "+tabela+". - "+situacao+".";
        }
        try {
            pst = c_db.conn.prepareStatement(sql);
            pst.setDate(1, DataSQL);
            pst.setString(2, acao);
            pst.setString(3, situacao);
            pst.setString(4, mensagem);
            pst.setString(5, usuario);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(gera_auditoria.class.getName()).log(Level.SEVERE, null, ex);
        }
        c_db.desconecta();
        
    }
    
}
