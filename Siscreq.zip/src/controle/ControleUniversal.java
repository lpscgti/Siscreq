/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.awt.Toolkit;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;

/**
 *
 * @author linde
 */
public class ControleUniversal {
    //Declara controles e variaveis:
    public java.sql.Date DataConvertidaSQL;
    public java.util.Date Data = new java.util.Date();
    public java.sql.Date Dt_agora;
    public String NomeComplemento, DataConvertidaString;
    public double ValorConvertido;
    DecimalFormat formatoNum;
    public String menssagem, menssagem_erro;
    SimpleDateFormat dtf = new SimpleDateFormat("dd/MM/yyyy");
    
    public void ColocaIconeJFrame(JFrame frame){
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"icone_16x16.png"));
    }
    
       
    public static void ColocaIconeJFrameStatic(JFrame frame){
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"icone_16x16.png"));
    }
    
    public void ColocaIconeInternalFrame(JInternalFrame frame){
        frame.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/icone_16x16.png")));
    }
    
    public void ConverteStringparaData(String Data){
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        String dtfSQLData = ano+"-"+mes+"-"+dia;
        DataConvertidaSQL = java.sql.Date.valueOf(dtfSQLData);
    }
    
    public void ConvertDataParaString(java.sql.Date Data){
        DataConvertidaString = dtf.format(Data);
     }
    
    public void GeraNomeComplementodeData(){
        SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");
        SimpleDateFormat dfhs = new SimpleDateFormat("HHmmss");
        String Dthoje = (df.format(Data));
        String Hagora = (dfhs.format(Data));
        NomeComplemento = Dthoje+Hagora;
    }
    
    public void GeraNomeComplementodeAno(){
        SimpleDateFormat df = new SimpleDateFormat("yyyy");
        String Ano = (df.format(Data));
        NomeComplemento = Ano;
    }
    
    public String SetData(String data, int dias) {//Soma String Data com numero. exmplo: 05/08/2023 + 2 = 07/08/2023
    String DataAlterada = "";
    String FormatoDaData = "dd/MM/yyyy";
    try {
        SimpleDateFormat format = new SimpleDateFormat(FormatoDaData);
        java.sql.Date Data = new java.sql.Date(format.parse(data).getTime());

        Calendar ob = Calendar.getInstance();
        ob.setTime(Data);
        ob.add(Calendar.DATE, +dias);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(FormatoDaData);
        DataAlterada = simpleDateFormat.format(ob.getTime());
    } catch (Exception e) {
        return "Data Inválida";//caso passe a data fora do formato
    }
    return DataAlterada;
    }
    
    public void convertValorVirgula(String ValorEntrada){
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
            try {
                ValorConvertido = formatoNum.parse(ValorEntrada).doubleValue();
            } catch (ParseException ex) {
                menssagem = ex.toString();
            }
        }
    }

}
