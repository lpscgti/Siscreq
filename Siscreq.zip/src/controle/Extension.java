/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import net.sf.jasperreports.view.JRSaveContributor;
import net.sf.jasperreports.view.save.JRCsvSaveContributor;
import net.sf.jasperreports.view.save.JRDocxSaveContributor;
import net.sf.jasperreports.view.save.JREmbeddedImagesXmlSaveContributor;
import net.sf.jasperreports.view.save.JRHtmlSaveContributor;
import net.sf.jasperreports.view.save.JRMultipleSheetsXlsSaveContributor;
import net.sf.jasperreports.view.save.JROdtSaveContributor;
import net.sf.jasperreports.view.save.JRPdfSaveContributor;
import net.sf.jasperreports.view.save.JRPrintSaveContributor;
import net.sf.jasperreports.view.save.JRRtfSaveContributor;
import net.sf.jasperreports.view.save.JRSingleSheetXlsSaveContributor;
import net.sf.jasperreports.view.save.JRXmlSaveContributor;

    /**
     *
     * @author linde
     */
    public enum Extension {
            PDF(JRPdfSaveContributor.class),
            RTF(JRRtfSaveContributor.class),
            SINGLE_SHEET_XLS(JRSingleSheetXlsSaveContributor.class),
            MULTIPLE_SHEET_XLS(JRMultipleSheetsXlsSaveContributor.class),
            DOCX(JRDocxSaveContributor.class),
            ODT(JROdtSaveContributor.class),
            HTML(JRHtmlSaveContributor.class),
            XML(JRXmlSaveContributor.class),
            CSV(JRCsvSaveContributor.class),
            PRINT(JRPrintSaveContributor.class),
            EMBEDDED_IMAGES_XML(JREmbeddedImagesXmlSaveContributor.class);

            private Class<? extends JRSaveContributor> clazz;

            Extension(Class<? extends JRSaveContributor> clazz) {
                this.clazz = clazz;
            }

            public Class<? extends JRSaveContributor> getClazz() {
                return clazz;
            }
    }
