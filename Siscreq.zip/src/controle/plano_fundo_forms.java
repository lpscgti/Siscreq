/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.border.Border;

/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */



public class plano_fundo_forms implements Border{
    //importações
    ConectaBanco conPlF = new ConectaBanco();
    obter_arquivo_conf o_ac = new obter_arquivo_conf();
            
    String caminhoImagem;
    int TamTelaAltura, TamTelaLargura;
    
    //public Graphics2D fundo;
    public BufferedImage back, back2;
 
    public plano_fundo_forms(int Altura, int Largura){
        
//        Dimension TamTela = Toolkit.getDefaultToolkit().getScreenSize(); //Código para obter o tamenho de altura e largura da tela.
        try {
            o_ac.ObterInfoConfig();
        } catch (IOException ex) {

        }
        TamTelaAltura = Altura;
        TamTelaLargura = Largura;
        
        try {
//           conPlF.conecta();
//           conPlF.executaSQL("select * from config where id_conf=1");
//           conPlF.rs.first();
//           caminhoImagem = conPlF.rs.getString("dados_conf_String");//obtem da tabela config o nome do arquivo de imagem
//           URL imagePath = new URL(this.getClass().getResource("/imagens/fundo_panel.png").toString());
            File file = new File(o_ac.plano_fundo_painel_arquivo);
            back = ImageIO.read(file);
        } catch (Exception ex) {            
        }
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        //g.drawImage(back, (x + (width - back.getWidth())/2),(y + (height - back.getHeight())/2), null);
        g.drawImage(back, x, y, TamTelaLargura, TamTelaAltura, c);
    }
    
    public Insets getBorderInsets(Component c) {
        return new Insets(0,0,0,0);
    }
 
    public boolean isBorderOpaque() {
        return false;
    }
 
}
   
         