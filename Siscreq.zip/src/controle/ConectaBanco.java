/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */
public class ConectaBanco {
    public Statement stm; //prepara as consulta ao dados no bd.
    public ResultSet rs; //retorna com os dados da consulta
    private String driver = "net.ucanaccess.jdbc.UcanaccessDriver";
    private String local;
    private String usuario = "";
    private String senha = "@s1scr3qXX";
    public Connection conn; //execulta conexao com o bd.
      
    obter_arquivo_conf o_ac = new obter_arquivo_conf();
        
    public void conecta(){
        
        try {
            o_ac.ObterInfoConfig();
            local = o_ac.servidor_local;
        } catch (IOException ex) {
            Logger.getLogger(ConectaBanco.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.setProperty("jdbc.Drivers", driver);
        try {
            conn = DriverManager.getConnection("jdbc:ucanaccess://"+local,usuario,senha);
        } catch (SQLException ex) {
            Logger.getLogger(ConectaBanco.class.getName()).log(Level.SEVERE, null, ex);
//            JOptionPane.showMessageDialog(null, "Houve um erro na conexão com o banco de dados, verifique se o arquivo config.ini, está com os parâmetros correto.");
        }
        
     }   
     
     
     public void executaSQL(String sql){
        try {
            stm = conn.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
                        Logger.getLogger(ConectaBanco.class.getName()).log(Level.SEVERE, null, ex);
        }
         
     }
     
     
     public void desconecta(){
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConectaBanco.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     
}
