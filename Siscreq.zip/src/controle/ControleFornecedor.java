/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import modelo.ModeloFornecedor;
import visual.FormPrincipal;

/**
 *
 * @author linde
 */
public class ControleFornecedor {
    //Declara Importações;
    ConectaBanco c_db = new ConectaBanco();
    ControleUniversal ctrl_uni = new ControleUniversal();
    public ModeloFornecedor mod_for = new ModeloFornecedor();
    
    //declara variaveis:
    public int cod_fornecedor;
    public String novo_reg, sql, menssagem_erro ,mensagem_erro_comp;
    java.sql.Date DataConvertidaSQL;
    PreparedStatement pst;
    public boolean novo_cad = false;
    public Date Data = new Date();
    public java.sql.Date Dagora;
    
    
    public void NovoRegistro(){
        c_db.conecta();
        ctrl_uni.GeraNomeComplementodeData();
        novo_reg = "Fornecedor"+ctrl_uni.NomeComplemento;
        sql = "insert into fornecedores (nome, data_cad, cad_por) values (?,?,?)";
        try {
                PreparedStatement pst = c_db.conn.prepareStatement(sql);
                pst.setString(1, novo_reg);
                pst.setDate(2, new java.sql.Date(Data.getTime()));
                pst.setString(3, FormPrincipal.UsuarioLogado);
                pst.execute();
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        try {
                sql= "select * from fornecedores where nome='"+novo_reg+"'";
                c_db.executaSQL(sql);
                c_db.rs.first();
                cod_fornecedor = c_db.rs.getInt("codigo");
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        novo_cad=true;
        c_db.desconecta();
    }
    
    public void ObterDadosFornecedor(int codcliente){
        c_db.conecta();
        sql = "select * from clientes where codigo='"+codcliente+"'";
        c_db.executaSQL(sql);
        try {
            if (c_db.rs.first()){
               mod_for.setCodigo(c_db.rs.getInt("codigo"));
               mod_for.setTipo(c_db.rs.getString("tipo"));
               mod_for.setNome(c_db.rs.getString("nome"));
               mod_for.setRazao_social(c_db.rs.getString("razao_social"));
               mod_for.setCpf_cnpj(c_db.rs.getString("cpf_cnpj"));
               mod_for.setEndereco(c_db.rs.getString("endereco"));
               mod_for.setBairro(c_db.rs.getString("bairro"));
               mod_for.setCidade(c_db.rs.getString("cidade"));
               mod_for.setEstado(c_db.rs.getString("estado"));
               mod_for.setCep(c_db.rs.getString("cep"));
               mod_for.setTelefone(c_db.rs.getString("telefone"));
               mod_for.setEmail(c_db.rs.getString("email"));
               mod_for.setSite(c_db.rs.getString("site"));
               mod_for.setObs(c_db.rs.getString("obs"));
            }
                
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        c_db.desconecta();
    }
    
    public boolean SalvaRegistro(ModeloFornecedor mod, boolean new_cad){
        c_db.conecta();
        if (new_cad==true){
            sql = "update fornecedores set tipo=?, nome=?, razao_social=?, cpf_cnpj=?, endereco=?, bairro=?, cidade=?, estado=?, cep=?, "
                + "telefone=?, email=?, site=?, obs=? where codigo=?";
                try {
                    pst = c_db.conn.prepareStatement(sql);
                    pst.setString(1, mod.getTipo());
                    pst.setString(2, mod.getNome());
                    pst.setString(3, mod.getRazao_social());
                    pst.setString(4, mod.getCpf_cnpj());
                    pst.setString(5, mod.getEndereco());
                    pst.setString(6, mod.getBairro());
                    pst.setString(7, mod.getCidade());
                    pst.setString(8, mod.getEstado());
                    pst.setString(9, mod.getCep());
                    pst.setString(10, mod.getTelefone());
                    pst.setString(11, mod.getEmail());
                    pst.setString(12, mod.getSite());
                    pst.setString(13, mod.getObs());
                    pst.setInt(14, mod.getCodigo());
                    int n=pst.executeUpdate();
                        if (n!=0){
                            return true;
                        }else{
                            return false;
                        }
                } catch (SQLException ex) {
                    menssagem_erro = ex.toString();
                }
        }else{
            sql = "update fornecedores set tipo=?, nome=?, razao_social=?, cpf_cnpj=?, endereco=?, bairro=?, cidade=?, estado=?, cep=?, "
                + "telefone=?, email=?, site=?, obs=?, mod_por=?, data_mod=? where codigo=?";
                try {
                    pst = c_db.conn.prepareStatement(sql);
                    pst.setString(1, mod.getTipo());
                    pst.setString(2, mod.getNome());
                    pst.setString(3, mod.getRazao_social());
                    pst.setString(4, mod.getCpf_cnpj());
                    pst.setString(5, mod.getEndereco());
                    pst.setString(6, mod.getBairro());
                    pst.setString(7, mod.getCidade());
                    pst.setString(8, mod.getEstado());
                    pst.setString(9, mod.getCep());
                    pst.setString(10, mod.getTelefone());
                    pst.setString(11, mod.getEmail());
                    pst.setString(12, mod.getSite());
                    pst.setString(13, mod.getObs());
                    pst.setString(14, mod.getMod_por());
                    pst.setDate(15, mod.getData_mod());
                    pst.setInt(16, mod.getCodigo());
                    int n=pst.executeUpdate();
                        if (n!=0){
                            return true;
                        }else{
                            return false;
                        }
                } catch (SQLException ex) {
                    menssagem_erro = ex.toString();
                }
        }
        c_db.desconecta();
        return false; 
    }
    
    public void ExcluiRegistro(ModeloFornecedor mod){
        c_db.conecta();
        sql = "delete from fornecedores where codigo=?";
        try {
            PreparedStatement pst = c_db.conn.prepareStatement(sql);
            pst.setInt(1, mod.getCodigo());
            pst.execute();
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        c_db.desconecta();
    }
    
    
}
