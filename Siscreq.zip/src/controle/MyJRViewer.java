/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import static controle.Extension.DOCX;
import static controle.Extension.HTML;
import static controle.Extension.ODT;
import static controle.Extension.PDF;
import static controle.Extension.RTF;
import java.lang.reflect.Constructor;
import java.util.Locale;
import java.util.ResourceBundle;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.swing.JRViewer;
import net.sf.jasperreports.swing.JRViewerToolbar;
import net.sf.jasperreports.view.JRSaveContributor;

/**
 *
 * @author linde
 */
    public class MyJRViewer extends JRViewer {

    private static final Extension[] extensions;

    static {
        //HERE YOU CAN ADD WHATEVER EXTENSION YOU WANT
        extensions = new Extension[]{PDF, RTF, DOCX, ODT, HTML};
        //ADD THIS IF YOU WANT ALL
        //extensions = Extension.values();
    }


    public MyJRViewer(JasperPrint jasperPrint) {
        super(jasperPrint);

    }

    @Override
    protected JRViewerToolbar createToolbar() {
        JRViewerToolbar toolbar = super.createToolbar();
        Locale locale = viewerContext.getLocale();
        ResourceBundle resBundle = viewerContext.getResourceBundle();

        JRSaveContributor[] jrsc = new JRSaveContributor[extensions.length];
        Class[] type = {Locale.class, ResourceBundle.class};
        Object[] obj = {locale, resBundle};
        for (int i = 0; i < extensions.length; i++) {
            try {
                Constructor cons = extensions[i].getClazz().getConstructor(type);
                jrsc[i] = (JRSaveContributor) cons.newInstance(obj);
            } catch (Exception x) {
                x.printStackTrace();
            }
        }

        toolbar.setSaveContributors(jrsc);
        return toolbar;
    }
}
