/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;
import visual.FormPrincipal;

/**
 *
 * @author linde
 */
public class ControleRelatorios {
    ConectaBanco c_db = new ConectaBanco();
    ControleEmpresa ctrl_de = new ControleEmpresa();
    String menssagem;
    
    
    public void AbreRelatorio(JasperPrint jpP){
        final MyJRViewer mrj = new MyJRViewer(jpP);
        mrj.setZoomRatio((float) 0.5);
        JFrame frameRelatorio = new JFrame();
        frameRelatorio.add( mrj, BorderLayout.CENTER );
        frameRelatorio.setTitle("Requisição");
        frameRelatorio.setSize( 500, 500 );
        frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
        frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
        Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
        frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"icone_16X16.png"));
        frameRelatorio.setVisible( true );
    }
    
    public boolean Print_Requisicao(int cod_req){
        ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(null, "Deseja realizar a impressão do Comprovante?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                    try {
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.png").getImage();
                            //dados empresa
                            parametros.put( "de_nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "de_cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "de_endereco", ctrl_de.de_endereco );
                            parametros.put( "de_bairro", ctrl_de.de_bairro );
                            parametros.put( "de_cidade", ctrl_de.de_cidade );
                            parametros.put( "de_estado", ctrl_de.de_estado );
                            parametros.put( "de_cep", ctrl_de.de_cep );
                            parametros.put( "de_fone1", ctrl_de.de_fone1 );
                            parametros.put( "de_fone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "de_email", ctrl_de.de_email );
                            //parametros do relatorio
                            parametros.put( "cod_req", cod_req );
                            parametros.put("ImgLogo",imagePath);
                            JasperPrint jpPrint;
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"requisicao.jasper", parametros, ConnectionFactory2.getSisConnection());
                            AbreRelatorio(jpPrint);
                            return true;
                    }   catch (SQLException ex) {
                            menssagem = ex.toString();
                            return false;
                    }   catch (JRException ex) {
                            menssagem = ex.toString();
                            return false;
                    }
            }
        return false;
    }
    
    public boolean FornecedoresNome(){
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        JUpperField jtfS = new JUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
            ctrl_de.Obtem_Dados_da_Empresa();
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
                NomeMod = Nome+"%";
            } else{
                NomeMod = "%"+Nome+"%";
            }
            int totforn = 0;
            
            c_db.conecta();
            c_db.executaSQL("select count (codigo) from fornecedores where nome like '"+NomeMod+"'");
            try {
                if (c_db.rs.first()){
                    totforn = c_db.rs.getInt(1);    
                }
            } catch (SQLException ex) {
                    menssagem = ex.toString();
            }
            c_db.desconecta();
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.png").getImage();
            //dados empresa
            parametros.put( "de_nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "de_cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "de_endereco", ctrl_de.de_endereco );
            parametros.put( "de_bairro", ctrl_de.de_bairro );
            parametros.put( "de_cidade", ctrl_de.de_cidade );
            parametros.put( "de_estado", ctrl_de.de_estado );
            parametros.put( "de_cep", ctrl_de.de_cep );
            parametros.put( "de_fone1", ctrl_de.de_fone1 );
            parametros.put( "de_fone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "de_email", ctrl_de.de_email );
            // parametros do relatorio
            parametros.put("ImgLogo",imagePath);
            parametros.put("Nome", NomeMod);
            parametros.put("totfornecedores",totforn);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Fornecedores_Consulta.jasper", parametros, ConnectionFactory2.getSisConnection());
            AbreRelatorio(jpPrint);
            } catch (SQLException ex) {
                menssagem = ex.toString();
            } catch (JRException ex) {
                menssagem = ex.toString();
                return false;
            }
        }
        return false;
    }//FornecedoresNome
    
    public boolean FornecedoresCpfCNPJ(){
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        JUpperField jtfS = new JUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
            ctrl_de.Obtem_Dados_da_Empresa();
            String pesquisa;
            String cpf_cnpj = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
                pesquisa = cpf_cnpj+"%";
            } else{
                pesquisa = "%"+cpf_cnpj+"%";
            }
            int totforn = 0;
            
            c_db.conecta();
            c_db.executaSQL("select count (codigo) from fornecedores where cpf_cnpj like '"+pesquisa+"'");
            try {
                if (c_db.rs.first()){
                    totforn = c_db.rs.getInt(1);    
                }
            } catch (SQLException ex) {
                    menssagem = ex.toString();
            }
            c_db.desconecta();
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.png").getImage();
            //dados empresa
            parametros.put( "de_nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "de_cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "de_endereco", ctrl_de.de_endereco );
            parametros.put( "de_bairro", ctrl_de.de_bairro );
            parametros.put( "de_cidade", ctrl_de.de_cidade );
            parametros.put( "de_estado", ctrl_de.de_estado );
            parametros.put( "de_cep", ctrl_de.de_cep );
            parametros.put( "de_fone1", ctrl_de.de_fone1 );
            parametros.put( "de_fone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "de_email", ctrl_de.de_email );
            // parametros do relatorio
            parametros.put("ImgLogo",imagePath);
            parametros.put("CPF_CNPJ", pesquisa);
            parametros.put("totfornecedores",totforn);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Fornecedores_Consulta_CPF_CNPJ.jasper", parametros, ConnectionFactory2.getSisConnection());
            AbreRelatorio(jpPrint);
            } catch (SQLException ex) {
                menssagem = ex.toString();
            } catch (JRException ex) {
                menssagem = ex.toString();
                return false;
            }
        }
        return false;
    }//FornecedoresCPF/CNPJ
    
    public boolean Requisicoes(){
        
            ctrl_de.Obtem_Dados_da_Empresa();
            int totreq = 0;
            c_db.conecta();
            c_db.executaSQL("select count (codigo) from requisicoes inner join fornecedores on fornecedores.codigo=requisicoes.fornecedor");
            try {
                if (c_db.rs.first()){
                    totreq = c_db.rs.getInt(1);    
                }
            } catch (SQLException ex) {
                    menssagem = ex.toString();
            }
            c_db.desconecta();
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.png").getImage();
            //dados empresa
            parametros.put( "de_nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "de_cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "de_endereco", ctrl_de.de_endereco );
            parametros.put( "de_bairro", ctrl_de.de_bairro );
            parametros.put( "de_cidade", ctrl_de.de_cidade );
            parametros.put( "de_estado", ctrl_de.de_estado );
            parametros.put( "de_cep", ctrl_de.de_cep );
            parametros.put( "de_fone1", ctrl_de.de_fone1 );
            parametros.put( "de_fone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "de_email", ctrl_de.de_email );
            // parametros do relatorio
            parametros.put("ImgLogo",imagePath);
            parametros.put("totRegistros",totreq);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Requisicoes_Consulta.jasper", parametros, ConnectionFactory2.getSisConnection());
            AbreRelatorio(jpPrint);
            } catch (SQLException ex) {
                menssagem = ex.toString();
            } catch (JRException ex) {
                menssagem = ex.toString();
                return false;
            }
        
        return false;
    }//Requisicoes
    
    public boolean RequisicoesAuto(){
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        JUpperField jtfS = new JUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
            ctrl_de.Obtem_Dados_da_Empresa();
            String pesquisa;
            String autorizado_por = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
                pesquisa = autorizado_por+"%";
            } else{
                pesquisa = "%"+autorizado_por+"%";
            }
            int totreq = 0;
            
            c_db.conecta();
            
            c_db.executaSQL("select count (codigo) from requisicoes inner join fornecedores on fornecedores.codigo=requisicoes.fornecedor where autorizado_por like '"+pesquisa+"'");
            try {
                if (c_db.rs.first()){
                    totreq = c_db.rs.getInt(1);    
                }
            } catch (SQLException ex) {
                    menssagem = ex.toString();
            }
            c_db.desconecta();
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.png").getImage();
            //dados empresa
            parametros.put( "de_nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "de_cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "de_endereco", ctrl_de.de_endereco );
            parametros.put( "de_bairro", ctrl_de.de_bairro );
            parametros.put( "de_cidade", ctrl_de.de_cidade );
            parametros.put( "de_estado", ctrl_de.de_estado );
            parametros.put( "de_cep", ctrl_de.de_cep );
            parametros.put( "de_fone1", ctrl_de.de_fone1 );
            parametros.put( "de_fone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "de_email", ctrl_de.de_email );
            // parametros do relatorio
            parametros.put("ImgLogo",imagePath);
            parametros.put("Nome", pesquisa);
            parametros.put("totRegistros",totreq);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Requisicoes_Consulta_auto.jasper", parametros, ConnectionFactory2.getSisConnection());
            AbreRelatorio(jpPrint);
            } catch (SQLException ex) {
                menssagem = ex.toString();
            } catch (JRException ex) {
                menssagem = ex.toString();
                return false;
            }
        }
        return false;
    }//RequisicoesAuto
    
    
    
    public boolean RequisicoesForn(){
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        JUpperField jtfS = new JUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
            ctrl_de.Obtem_Dados_da_Empresa();
            String pesquisa;
            String fornecedor = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
                pesquisa = fornecedor+"%";
            } else{
                pesquisa = "%"+fornecedor+"%";
            }
            int totreq = 0;
            
            c_db.conecta();
            
            c_db.executaSQL("select count (codigo) from requisicoes inner join fornecedores on fornecedores.codigo=requisicoes.fornecedor where nome like '"+pesquisa+"'");
            try {
                if (c_db.rs.first()){
                    totreq = c_db.rs.getInt(1);    
                }
            } catch (SQLException ex) {
                    menssagem = ex.toString();
            }
            c_db.desconecta();
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.png").getImage();
            //dados empresa
            parametros.put( "de_nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "de_cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "de_endereco", ctrl_de.de_endereco );
            parametros.put( "de_bairro", ctrl_de.de_bairro );
            parametros.put( "de_cidade", ctrl_de.de_cidade );
            parametros.put( "de_estado", ctrl_de.de_estado );
            parametros.put( "de_cep", ctrl_de.de_cep );
            parametros.put( "de_fone1", ctrl_de.de_fone1 );
            parametros.put( "de_fone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "de_email", ctrl_de.de_email );
            // parametros do relatorio
            parametros.put("ImgLogo",imagePath);
            parametros.put("Nome", pesquisa);
            parametros.put("totRegistros",totreq);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Requisicoes_Consulta_Forn.jasper", parametros, ConnectionFactory2.getSisConnection());
            AbreRelatorio(jpPrint);
            } catch (SQLException ex) {
                menssagem = ex.toString();
            } catch (JRException ex) {
                menssagem = ex.toString();
                return false;
            }
        }
        return false;
    }//RequisicoesForn
    
    public boolean RequisicoesReq(){
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        JUpperField jtfS = new JUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
            ctrl_de.Obtem_Dados_da_Empresa();
            String pesquisa;
            String requisitante = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
                pesquisa = requisitante+"%";
            } else{
                pesquisa = "%"+requisitante+"%";
            }
            int totreq = 0;
            
            c_db.conecta();
            
            c_db.executaSQL("select count (codigo) from requisicoes inner join fornecedores on fornecedores.codigo=requisicoes.fornecedor where requisitador_por like '"+pesquisa+"'");
            try {
                if (c_db.rs.first()){
                    totreq = c_db.rs.getInt(1);    
                }
            } catch (SQLException ex) {
                    menssagem = ex.toString();
            }
            c_db.desconecta();
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.png").getImage();
            //dados empresa
            parametros.put( "de_nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "de_cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "de_endereco", ctrl_de.de_endereco );
            parametros.put( "de_bairro", ctrl_de.de_bairro );
            parametros.put( "de_cidade", ctrl_de.de_cidade );
            parametros.put( "de_estado", ctrl_de.de_estado );
            parametros.put( "de_cep", ctrl_de.de_cep );
            parametros.put( "de_fone1", ctrl_de.de_fone1 );
            parametros.put( "de_fone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "de_email", ctrl_de.de_email );
            // parametros do relatorio
            parametros.put("ImgLogo",imagePath);
            parametros.put("Nome", pesquisa);
            parametros.put("totRegistros",totreq);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Requisicoes_Consulta_Req.jasper", parametros, ConnectionFactory2.getSisConnection());
            AbreRelatorio(jpPrint);
            } catch (SQLException ex) {
                menssagem = ex.toString();
            } catch (JRException ex) {
                menssagem = ex.toString();
                return false;
            }
        }
        return false;
    }//RequisicoesReq
}
