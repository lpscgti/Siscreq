/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;


import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JDesktopPane;
import javax.swing.border.Border;


/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */

public class plano_fundo_janelaprincipal implements Border{
    String local,nome;
    String caminhoImagem;
    int TamTelaAltura, TamTelaLargura, TA, TL;
    public BufferedImage back;
    obter_arquivo_conf o_ac = new obter_arquivo_conf();
 

    public plano_fundo_janelaprincipal(JDesktopPane jdesk){
        
        try {
            o_ac.ObterInfoConfig();
        } catch (IOException ex) {
            Logger.getLogger(plano_fundo_janelaprincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        Dimension TamTela = Toolkit.getDefaultToolkit().getScreenSize(); //Código para obter o tamenho de altura e largura da tela.
        TamTelaAltura = (int) TamTela.getHeight();//Armazena a altura
        TamTelaLargura = (int) TamTela.getWidth();//Armazena a largura
        TA = jdesk.getHeight();
        TL = jdesk.getWidth();
        try {
            File file = new File(o_ac.plano_fundo_arquivo);
//            JOptionPane.showMessageDialog(null, file);
            back = ImageIO.read(file);
        } catch (Exception ex) {            
        }
        
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
//        g.drawImage(back, (x + (width - back.getWidth())/2),(y + (height - back.getHeight())/2), null);
    g.drawImage(back, x, y, TL, TA, c);
        
    }
 
    public Insets getBorderInsets(Component c) {
        return new Insets(0,0,0,0);
    }
 
    public boolean isBorderOpaque() {
        return false;
    }
 
}
   
         