/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.ModeloDadosEmpresa;

/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */
//declara importações;
public class ControleEmpresa {
ConectaBanco c_db = new ConectaBanco();
public String menssagem;
//declara variaves de dados da empresa;
public String de_nomefantasia, de_rasao, de_cnpj, de_ie, de_endereco, de_bairro, de_cidade, de_estado, de_cep, de_fone1, de_fone2, de_site, de_email;
String sql;
       
    
    public void Obtem_Dados_da_Empresa(){
        c_db.conecta();
        sql = "select * from dados_empresa where codigo='1'";
        c_db.executaSQL(sql);
        try {
            if (c_db.rs.first()){
                de_nomefantasia = c_db.rs.getString("nomefantasia");
                de_rasao = c_db.rs.getString("razaosocial");
                de_cnpj = c_db.rs.getString("cnpj");
                de_ie = c_db.rs.getString("ie");
                de_endereco = c_db.rs.getString("endereco");
                de_bairro = c_db.rs.getString("bairro");
                de_cidade = c_db.rs.getString("cidade");
                de_estado = c_db.rs.getString("estado");
                de_cep = c_db.rs.getString("cep");
                de_fone1 = c_db.rs.getString("fone1");
                de_fone2 = c_db.rs.getString("fone2");
                de_site =  c_db.rs.getString("site");
                de_email = c_db.rs.getString("email");
            }
        } catch (SQLException ex) {
            menssagem = ex.toString();
        }
        c_db.desconecta();
    }
    
    public void AlteraDados(ModeloDadosEmpresa modDE){
    c_db.conecta();
    try {
        PreparedStatement pst = c_db.conn.prepareStatement("update dados_empresa set nomefantasia=?, razaosocial=?, cnpj=?, ie=?, endereco=?, bairro=?, cidade=?, estado=?, cep=?, fone1=?, fone2=?, site=?, email=? where codigo=?");
        pst.setString(1, modDE.getNF());
        pst.setString(2, modDE.getRS());
        pst.setString(3, modDE.getCNPJ());
        pst.setString(4, modDE.getIE());
        pst.setString(5, modDE.getEnd());
        pst.setString(6, modDE.getBai());
        pst.setString(7, modDE.getCid());
        pst.setString(8, modDE.getEst());
        pst.setString(9, modDE.getCep());
        pst.setString(10, modDE.getF1());
        pst.setString(11, modDE.getF2());
        pst.setString(12, modDE.getSite());
        pst.setString(13, modDE.getEmail());
        pst.setInt(14, modDE.getCod());
        pst.execute();
    } catch (SQLException ex) {
        menssagem = ex.toString();
    }
    c_db.desconecta();
    }

}
