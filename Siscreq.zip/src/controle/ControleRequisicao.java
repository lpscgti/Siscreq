/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import modelo.ModeloFornecedor;
import modelo.ModeloRequisicao;
import modelo.ModeloRequisicaoDesc;
import visual.FormPrincipal;

/**
 *
 * @author linde
 */
public class ControleRequisicao {
    //Declara importações;
    ConectaBanco c_db = new ConectaBanco();
    public ModeloRequisicao mod_req = new ModeloRequisicao();
    ModeloRequisicaoDesc mod_req_desc = new ModeloRequisicaoDesc();
    ControleUniversal ctrl_uni = new ControleUniversal();
    
    //Declara variaveis;
    public int cod_requisicao, novo_reg;
    public String sql, menssagem_erro ,mensagem_erro_comp;
    java.sql.Date DataConvertidaSQL;
    PreparedStatement pst;
    public boolean novo_cad = false;
    public Date Data = new Date();
    public java.sql.Date Dagora;
    
    
    public void NovoRegistro(){
        c_db.conecta();
        int n_ultimo_cad = 0;
        int n_cad_atual = 1000;
            try {
                sql= "select * from requisicoes";
                c_db.executaSQL(sql);
                if (c_db.rs.first()){
                    n_ultimo_cad = c_db.rs.getInt("codigo");
                }
            } catch (SQLException ex) {
                menssagem_erro = ex.toString();
            }
        if (n_ultimo_cad>=1000){
            n_cad_atual = n_ultimo_cad+1;
        }else{
            n_cad_atual = n_cad_atual+1;
        }
        novo_reg = n_cad_atual;
        cod_requisicao = novo_reg;
        sql = "insert into requisicoes (codigo,status,data_cad, cad_por) values (?,?,?,?)";
            try {
                PreparedStatement pst = c_db.conn.prepareStatement(sql);
                pst.setInt(1, novo_reg);
                pst.setString(2, "a_retorno");
                pst.setDate(3, new java.sql.Date(Data.getTime()));
                pst.setString(4, FormPrincipal.UsuarioLogado);
                pst.execute();
            } catch (SQLException ex) {
                menssagem_erro = ex.toString();
            }
        novo_cad=true;
        c_db.desconecta();
    }
    
    public boolean SalvaRegistro(ModeloRequisicao mod, boolean new_cad){
        
        c_db.conecta();
        if (new_cad==true){
            sql = "update requisicoes set data=?, fornecedor=?, requisitado_por=?, autorizado=?, autorizado_por=?, status=?, "
                    + "motivo_status=?, obs=? where codigo=?";
            
                try {
                    pst = c_db.conn.prepareStatement(sql);
                    pst.setDate(1, mod.getData());
                    pst.setInt(2, mod.getFornecedor_cod());
                    pst.setString(3, mod.getRequisitado_por());
                    pst.setString(4, mod.getAutorizado());
                    pst.setString(5, mod.getAutorizado_por());
                    pst.setString(6, mod.getStatus());
                    pst.setString(7, mod.getMotivo_status());
                    pst.setString(8, mod.getObs());
                    pst.setInt(9, mod.getCodigo());
                    int n=pst.executeUpdate();
                        if (n!=0){
                            return true;
                        }else{
                            return false;
                        }
                } catch (SQLException ex) {
                    menssagem_erro = ex.toString();
                }
        }else{
            sql = "update requisicoes set data=?, fornecedor=?, requisitado_por=?, autorizado=?, autorizado_por=?, status=?, "
                    + "motivo_status=?, obs=?, mod_por=?, data_mod=? where codigo=?";
                try {
                    
                    pst = c_db.conn.prepareStatement(sql);
                    pst.setDate(1, mod.getData());
                    pst.setInt(2, mod.getFornecedor_cod());
                    pst.setString(3, mod.getRequisitado_por());
                    pst.setString(4, mod.getAutorizado());
                    pst.setString(5, mod.getAutorizado_por());
                    pst.setString(6, mod.getStatus());
                    pst.setString(7, mod.getMotivo_status());
                    pst.setString(8, mod.getObs());
                    pst.setString(9, mod.getMod_por());
                    pst.setDate(10, mod.getData_mod());
                    pst.setInt(11, mod.getCodigo());
                    int n=pst.executeUpdate();
                        if (n!=0){
                            return true;
                        }else{
                            return false;
                        }
                } catch (SQLException ex) {
                    menssagem_erro = ex.toString();
                }
        }
        c_db.desconecta();
        
        
        return false;
    }
    
    public boolean Add_item(ModeloRequisicaoDesc mod_desc){
        c_db.conecta();
        sql = "insert into requisicoes_desc (requisicao_cod, discriminacao, tipo_und, qtd) values (?,?,?,?)";
        try {
            pst = c_db.conn.prepareStatement(sql);
            pst.setInt(1, mod_desc.getRequisicao_cod());
            pst.setString(2, mod_desc.getDescriminacao());
            pst.setString(3, mod_desc.getTipo_und());
            pst.setInt(4, mod_desc.getQtd());
            int n=pst.executeUpdate();
            if (n!=0){
                return true;
            }else{
                return false;
            }
        } catch (SQLException ex){
            menssagem_erro = ex.toString();
        }
        c_db.desconecta();
        return false;
    }
    
    public boolean Rem_item(ModeloRequisicaoDesc mod_desc){
        c_db.conecta();
        sql = "delete from requisicoes_desc where codigo=?";
        try {
            pst = c_db.conn.prepareStatement(sql);
            pst.setInt(1, mod_desc.getCodigo());
            int n=pst.executeUpdate();
            if (n!=0){
                return true;
            }else{
                return false;
            }
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        c_db.desconecta();
        return false;
    }
    
    
    
    public void ExcluiRegistro(ModeloRequisicao mod){
        c_db.conecta();
        
        sql = "delete from requisicoes_desc where requisicao_cod=?";
        try {
            pst = c_db.conn.prepareStatement(sql);
            pst.setInt(1, mod.getCodigo());
            pst.execute();
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        
        sql = "delete from requisicoes where codigo=?";
        try {
            pst = c_db.conn.prepareStatement(sql);
            pst.setInt(1, mod.getCodigo());
            pst.execute();
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        c_db.desconecta();
    }
    
    public void ObterDados(int codreq){
        c_db.conecta();
        sql = "select * from requisicoes where codigo='"+codreq+"'";
        c_db.executaSQL(sql);
        try {
            if (c_db.rs.first()){
               mod_req.setCodigo(c_db.rs.getInt("codigo"));
               mod_req.setData(c_db.rs.getDate("data"));
               mod_req.setFornecedor_cod(c_db.rs.getInt("fornecedor"));
               mod_req.setRequisitado_por(c_db.rs.getString("requisitado_por"));
               mod_req.setAutorizado(c_db.rs.getString("autorizado"));
               mod_req.setAutorizado_por(c_db.rs.getString("autorizado_por"));
               mod_req.setStatus(c_db.rs.getString("status"));
            }
        } catch (SQLException ex) {
            menssagem_erro = ex.toString();
        }
        c_db.desconecta();
    }
        
        
    
    
    
    
}
