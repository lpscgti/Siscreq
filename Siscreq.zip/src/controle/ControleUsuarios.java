/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.ModeloUsuarios;
import visual.FormPrincipal;
import visual.FormUsuarios;

/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */
public class ControleUsuarios {
    //Declara Importações e Variaveis:
    ConectaBanco conLogin = new ConectaBanco();
    ModeloUsuarios  modLogin = new ModeloUsuarios();
    ControleUniversal ctrl_univ = new ControleUniversal();
    public java.util.Date Data = new java.util.Date();
    public java.sql.Date Dt_agora;
    public int Codigo;
    public long DiferencaDts;
    
    
    public void NovoUsuario(){
        conLogin.conecta();
        ctrl_univ.GeraNomeComplementodeData();
        try {
            PreparedStatement pst = conLogin.conn.prepareStatement("insert into usuarios (nome,permissao,cad_por,data_cad) values (?,?,?,?)");
            pst.setString(1, "XXX");
            pst.setString(2, "XXX");
            pst.setString(3,FormPrincipal.UsuarioLogado);
            pst.setDate(4, ctrl_univ.Dt_agora);
            pst.execute();
            conLogin.executaSQL("select * from usuarios where nome='XXX'");
            conLogin.rs.last();
            Codigo = conLogin.rs.getInt("codigo");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
            Logger.getLogger(FormUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        conLogin.desconecta();
    }
   
   public void ComparaDataCad(String Data){
       try {
  
       Date hoje = new Date();
       GregorianCalendar dtH = new GregorianCalendar();
       GregorianCalendar dtC = new GregorianCalendar();
       SimpleDateFormat dtf = new SimpleDateFormat("dd/MM/yyyy");
       String DHoje = (dtf.format(hoje));
       dtH.setTime(dtf.parse(DHoje));
       long dth = dtH.getTimeInMillis();
       dtC.setTime(dtf.parse(Data));
       long dtc = dtC.getTimeInMillis();
       long dif = dth-dtc;
       DiferencaDts = dif / 86400000;
       
       } catch (ParseException ex) {
            Logger.getLogger(ControleUsuarios.class.getName()).log(Level.SEVERE, null, ex);
       }       
   }
    
   public void SalvaUsuario(ModeloUsuarios mod){
       
       try {
           
                PreparedStatement pst;
                pst = conLogin.conn.prepareStatement("update usuarios set nome=?, login=?, senha=?, permissao=?, mod_por, dta where codigo=?");
                pst.setString(1, mod.getNome());
                pst.setString(2, mod.getLogin());
                pst.setString(3, mod.getSenha());
                pst.setInt(4, mod.getPermissao());
                pst.setInt(5, mod.getCodigo());
                pst.execute();
                
                
       } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex);
        Logger.getLogger(ControleUsuarios.class.getName()).log(Level.SEVERE, null, ex);
       }
       conLogin.desconecta();
   }
   
   public void AtualizaUsuario(ModeloUsuarios mod){
       
       conLogin.conecta();
       PreparedStatement pst;
       try {
       pst = conLogin.conn.prepareStatement("update usuarios set senha=?, permissao=? where codigo=?");
       pst.setString(1, mod.getSenha());
       pst.setInt(2, mod.getPermissao());
       pst.setInt(3, mod.getCodigo());
       pst.execute();
       } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex);
        Logger.getLogger(ControleUsuarios.class.getName()).log(Level.SEVERE, null, ex);
       }
       conLogin.desconecta();
   }
   
   public void ExcluirUsuario(ModeloUsuarios mod){
       
       conLogin.conecta();
       PreparedStatement pst;
       try {
       pst = conLogin.conn.prepareStatement("delete from usuarios where codigo=?");
       pst.setInt(1, mod.getCodigo());
       pst.execute();
       } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex);
        Logger.getLogger(ControleUsuarios.class.getName()).log(Level.SEVERE, null, ex);
       }
       conLogin.desconecta();
   
    }
    
    }
