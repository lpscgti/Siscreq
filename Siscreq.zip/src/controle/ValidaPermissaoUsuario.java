/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import visual.DialogValidaUsuario;
import visual.FormPrincipal;

/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com Pereira
 */
public class ValidaPermissaoUsuario {
    //declara importações;
    ConectaBanco c_db = new ConectaBanco();
    
    //declara variaveis;
    PreparedStatement pst;
    String sql, user_tmp, senha_tmp, permissao_tmp, mensagem;
    int permissao;
    boolean b_tmp = false;
    public boolean user_inv = false;
    public String usuario_inv;
    

    public boolean  ValidaPermissao(String Acao){
     
        permissao = FormPrincipal.UsuarioPermissao;
        if (Acao.equals("salvar")){
            if (permissao>=2){
                return true;
            }else{
                QuestionaPermissao();
                    if (b_tmp==true){
                        return true;
                    }else{
                        return false;
                    }
                
            }
               
        }if (Acao.equals("excluir")){
            if(permissao==3){
                return true;
            }else{
                QuestionaPermissao();
                    if (b_tmp==true){
                        return true;
                    }else{
                        return false;
                    }
                
            } 
            
        }
        return false;
        
    }
    
    public void QuestionaPermissao(){
        
            String local_img_icone;
            Path caminhoTXT;
            caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
            local_img_icone = caminhoTXT+"/"+"gta_control_icone_16X16.png";
            JOptionPane jop = new JOptionPane();
                        
                int i = jop.showInternalConfirmDialog(FormPrincipal.AreaDeTrabalhoPrincipal, "O usuário não possui direitos para realizar cadastros.\n Deseja elevar permissão usando outro usuario e senha?","Confirmando Permissão", JOptionPane.YES_NO_OPTION,2);
                if(i == JOptionPane.YES_OPTION) {
                    DialogValidaUsuario DiagUser = new DialogValidaUsuario();
                    DiagUser.setModal(true);
                    DiagUser.setVisible(true);
                    String UsuarioDiag = DiagUser.usuario;
                    String SenhaDiag = DiagUser.senha;
                    BuscaUsuario(UsuarioDiag, SenhaDiag);
                    user_inv=true;
                    usuario_inv = UsuarioDiag;
                }
                
    }
    
    public void BuscaUsuario(String user, String senha){
        
        c_db.conecta();
        sql = "select * from usuarios where login='"+user+"'";
        c_db.executaSQL(sql);
        try {
            if (c_db.rs.first()){
                String pass_rs = c_db.rs.getString("senha");
                if (pass_rs.equals(senha)){
//                    JOptionPane.showMessageDialog(null, "confirmado");
                    b_tmp = true;
                }
            }
        } catch (SQLException ex) {
           mensagem = ex.toString();
           JOptionPane.showMessageDialog(null, mensagem);
           b_tmp = false;
        }
        c_db.desconecta();
        
    }
    
    public void VerCapsLock(JPasswordField jtxt, JLabel jlab){
        
        Toolkit tk = Toolkit.getDefaultToolkit();    
        
            if(tk.getLockingKeyState(KeyEvent.VK_CAPS_LOCK)){
                jlab.setText("Caps Lock está ativada");
                jlab.setVisible(true);
            }else{
                jlab.setText("");
                jlab.setVisible(false);
            }
        
    }
    
    
}
