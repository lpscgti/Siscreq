/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author linde
 */
public class ModeloRequisicao {

    /**
     * @return the Obs
     */
    public String getObs() {
        return Obs;
    }

    /**
     * @param Obs the Obs to set
     */
    public void setObs(String Obs) {
        this.Obs = Obs;
    }

    /**
     * @return the fornecedor_cod
     */
    public int getFornecedor_cod() {
        return fornecedor_cod;
    }

    /**
     * @param fornecedor_cod the fornecedor_cod to set
     */
    public void setFornecedor_cod(int fornecedor_cod) {
        this.fornecedor_cod = fornecedor_cod;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the data
     */
    public java.sql.Date getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(java.sql.Date data) {
        this.data = data;
    }

    /**
     * @return the requisitado_por
     */
    public String getRequisitado_por() {
        return requisitado_por;
    }

    /**
     * @param requisitado_por the requisitado_por to set
     */
    public void setRequisitado_por(String requisitado_por) {
        this.requisitado_por = requisitado_por;
    }

    /**
     * @return the autorizado
     */
    public String getAutorizado() {
        return autorizado;
    }

    /**
     * @param autorizado the autorizado to set
     */
    public void setAutorizado(String autorizado) {
        this.autorizado = autorizado;
    }

    /**
     * @return the autorizado_por
     */
    public String getAutorizado_por() {
        return autorizado_por;
    }

    /**
     * @param autorizado_por the autorizado_por to set
     */
    public void setAutorizado_por(String autorizado_por) {
        this.autorizado_por = autorizado_por;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the motivo_status
     */
    public String getMotivo_status() {
        return motivo_status;
    }

    /**
     * @param motivo_status the motivo_status to set
     */
    public void setMotivo_status(String motivo_status) {
        this.motivo_status = motivo_status;
    }

    /**
     * @return the data_cad
     */
    public java.sql.Date getData_cad() {
        return data_cad;
    }

    /**
     * @param data_cad the data_cad to set
     */
    public void setData_cad(java.sql.Date data_cad) {
        this.data_cad = data_cad;
    }

    /**
     * @return the cad_por
     */
    public String getCad_por() {
        return cad_por;
    }

    /**
     * @param cad_por the cad_por to set
     */
    public void setCad_por(String cad_por) {
        this.cad_por = cad_por;
    }

    /**
     * @return the data_mod
     */
    public java.sql.Date getData_mod() {
        return data_mod;
    }

    /**
     * @param data_mod the data_mod to set
     */
    public void setData_mod(java.sql.Date data_mod) {
        this.data_mod = data_mod;
    }

    /**
     * @return the mod_por
     */
    public String getMod_por() {
        return mod_por;
    }

    /**
     * @param mod_por the mod_por to set
     */
    public void setMod_por(String mod_por) {
        this.mod_por = mod_por;
    }
    private int codigo;
    private java.sql.Date data;
    private int fornecedor_cod;
    private String requisitado_por;
    private String autorizado;
    private String autorizado_por;
    private String status;
    private String motivo_status;
    private java.sql.Date data_cad;
    private String cad_por;
    private java.sql.Date data_mod;
    private String mod_por;
    private String Obs;
}
