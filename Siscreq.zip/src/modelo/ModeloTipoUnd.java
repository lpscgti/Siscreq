/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author linde
 */
public class ModeloTipoUnd {

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the data_cad
     */
    public java.sql.Date getData_cad() {
        return data_cad;
    }

    /**
     * @param data_cad the data_cad to set
     */
    public void setData_cad(java.sql.Date data_cad) {
        this.data_cad = data_cad;
    }

    /**
     * @return the cad_por
     */
    public String getCad_por() {
        return cad_por;
    }

    /**
     * @param cad_por the cad_por to set
     */
    public void setCad_por(String cad_por) {
        this.cad_por = cad_por;
    }

    /**
     * @return the data_mod
     */
    public java.sql.Date getData_mod() {
        return data_mod;
    }

    /**
     * @param data_mod the data_mod to set
     */
    public void setData_mod(java.sql.Date data_mod) {
        this.data_mod = data_mod;
    }

    /**
     * @return the mod_por
     */
    public String getMod_por() {
        return mod_por;
    }

    /**
     * @param mod_por the mod_por to set
     */
    public void setMod_por(String mod_por) {
        this.mod_por = mod_por;
    }
    private int codigo;
    private String tipo;
    private java.sql.Date data_cad;
    private String cad_por;
    private java.sql.Date data_mod;
    private String mod_por;
}
