/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */
public class ModeloTabelaColorRenderContas_A_Pagar extends DefaultTableCellRenderer {
 
    public String NomeTabela;
    
    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value,
            boolean isSelected, boolean hasFocus,
            int row, int column) {
 
        super.getTableCellRendererComponent(table, value, isSelected,
                hasFocus, row, column);
         
        // seta o resultado p/ falso porque isso sera usado em varias Jtables do sistema
        boolean result = false;
        try{

        }
        catch (java.lang.NullPointerException ex){
            
        }
         
               
        setFont(new Font("ARIAL",Font.PLAIN,12));

        if (isSelected) {
            
            setBackground(new Color(32, 178, 170));
            setForeground(Color.WHITE);
            setFont(new Font("ARIAL",Font.BOLD,14));

             
        } else {
            
//            if (row == 0){ //Coloar Cor fixa na Primeira linha da tabela
//            
//                setBackground(new Color(255, 215, 0));
//                setForeground(Color.BLUE);
//            
//            }else 
                if ((row % 2 == 0)) {//Especifica cor para linhas pares
                
                setBackground(new Color(254, 205, 114));
                setForeground(Color.black);
                
            } else {//Especifica cor para linhas impares
            
                setBackground(new Color(253,238,176));
                setForeground(Color.black);
            }
        }
        
        //Alinhamento do texto nas colunas
        if (column == 0){
            setHorizontalAlignment(SwingConstants.RIGHT);
        }
        
        if (column == 1){
            setHorizontalAlignment(SwingConstants.LEFT);
        }
        
        if (column == 2){
            setHorizontalAlignment(SwingConstants.CENTER);
        }
        
        if (column == 3){
            setHorizontalAlignment(SwingConstants.RIGHT);
        }
        
        if (column == 4){
            setHorizontalAlignment(SwingConstants.LEFT);
        }
        
        return this;
    }
}

