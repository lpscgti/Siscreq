/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author linde
 */
public class ModeloRequisicaoDesc {

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the requisicao_cod
     */
    public int getRequisicao_cod() {
        return requisicao_cod;
    }

    /**
     * @param requisicao_cod the requisicao_cod to set
     */
    public void setRequisicao_cod(int requisicao_cod) {
        this.requisicao_cod = requisicao_cod;
    }

    /**
     * @return the descriminacao
     */
    public String getDescriminacao() {
        return descriminacao;
    }

    /**
     * @param descriminacao the descriminacao to set
     */
    public void setDescriminacao(String descriminacao) {
        this.descriminacao = descriminacao;
    }

    /**
     * @return the tipo_und
     */
    public String getTipo_und() {
        return tipo_und;
    }

    /**
     * @param tipo_und the tipo_und to set
     */
    public void setTipo_und(String tipo_und) {
        this.tipo_und = tipo_und;
    }

    /**
     * @return the qtd
     */
    public int getQtd() {
        return qtd;
    }

    /**
     * @param qtd the qtd to set
     */
    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    private int codigo;
    private int requisicao_cod;
    private String descriminacao;
    private String tipo_und;
    private int qtd;
    
}
