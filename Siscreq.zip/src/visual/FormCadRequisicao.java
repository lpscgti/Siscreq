/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package visual;

import controle.ConectaBanco;
import controle.ControleRelatorios;
import controle.ControleRequisicao;
import controle.ControleUniversal;
import controle.ValidaPermissaoUsuario;
import controle.plano_fundo_forms;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.beans.PropertyVetoException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import modelo.ModeloRequisicao;
import modelo.ModeloRequisicaoDesc;
import modelo.ModeloTabela;

/**
 *
 * @author linde
 */
public class FormCadRequisicao extends javax.swing.JInternalFrame {

    //declara importacoes:
    ConectaBanco c_db = new ConectaBanco();
    ControleRequisicao ctrl_req = new ControleRequisicao();
    ValidaPermissaoUsuario valida_peruser = new ValidaPermissaoUsuario();
    ControleUniversal ctrl_uni = new ControleUniversal();
    ControleRelatorios ctrl_rel = new ControleRelatorios();
    ModeloRequisicao mod_req = new ModeloRequisicao();
    ModeloRequisicaoDesc mod_req_desc = new ModeloRequisicaoDesc();
    
    //declara variaveis
    public boolean a_form_ex = false; //identifica se o jormulario foi aberto a partir de outro formulario.
    public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.
    int cod_requisicao, cod_fornecedor=0, idSel;
    String nome_fornecedor="";
    String autorizado_por;
    boolean novo_cad = false, item_add = false, e_alteracao = false;
    String mensagem, sql;
    java.sql.Date Data;
    public Date DataH = new Date();
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    java.sql.Date DataConvertidaSQL;
    
    /**
     * Creates new form FormCadRequisicao
     */
    public FormCadRequisicao() {
        initComponents();
        ColocaImagemFundoFrame();
        IniciaComp();
        LimpaItens();
        DesativaItens();
        ObtemListaUND();
    }
    
     public void IniciaComp(){
        jtf_codigo.setEditable(false);
        jtf_fornecedor.setEditable(false);
        jbt_novo.setEnabled(true);
        jbt_editar.setEnabled(false);
        jbt_excluir.setEnabled(false);
        jbt_salvar.setEnabled(false);
        jbt_sair.setEnabled(true);
    }
    
    public void LimpaItens(){
        jtf_codigo.setText("");
        jdt_data.setDate(null);
        jtf_fornecedor.setText("");
        jbt_pesquisar.setText("");
        jtf_requisitante.setText("");
        jtf_descriminacao.setText("");
        jcb_und.setSelectedItem("UND");
        jtf_qtd.setText("1");
        jcb_autorizar.setSelectedIndex(0);
    }
    
    public void LimpaItensDesc(){
        jtf_descriminacao.setText("");
        jcb_und.setSelectedItem("UND");
        jtf_qtd.setText("1");
    }
    
     public void LimpaTabela(){
      ArrayList dados = new ArrayList();
      String[] Colunas = new String[]{};
      dados.removeAll(dados);
      ModeloTabela modelo = new ModeloTabela(dados, Colunas);
      jtb_desc.setModel(modelo);
      
    }
    
    public void AtivaItens(){
        jtf_codigo.setEnabled(true);
        jdt_data.setEnabled(true);
        jtf_fornecedor.setEnabled(true);
        jbt_pesquisar.setEnabled(true);
        jtf_requisitante.setEnabled(true);
        jtf_descriminacao.setEnabled(true);
        jcb_und.setEnabled(true);
        jtf_qtd.setEnabled(true);
        jbt_add.setEnabled(true);
        jbt_rem.setEnabled(true);
        jcb_autorizar.setEnabled(true);
    }
    
    public void DesativaItens(){
        jtf_codigo.setEnabled(false);
        jdt_data.setEnabled(false);
        jtf_fornecedor.setEnabled(false);
        jbt_pesquisar.setEnabled(false);
        jtf_requisitante.setEnabled(false);
        jtf_descriminacao.setEnabled(false);
        jcb_und.setEnabled(false);
        jtf_qtd.setEnabled(false);
        jbt_add.setEnabled(false);
        jbt_rem.setEnabled(false);
        jcb_autorizar.setEnabled(false);
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        PainelFundo.setBorder(new plano_fundo_forms(AlturaForm, LarguraForm));
    }
    
    public void ObtemDados(int codreq){
        if (codreq!=0){
            cod_requisicao = codreq;
            ctrl_req.ObterDados(codreq);
            e_alteracao = true;
            LimpaItens();
            jtf_codigo.setText(String.valueOf(ctrl_req.mod_req.getCodigo()));
            jdt_data.setDate(ctrl_req.mod_req.getData());
            cod_fornecedor = ctrl_req.mod_req.getFornecedor_cod();
            BuscaNomeFornecdor(cod_fornecedor);
            jtf_fornecedor.setText(nome_fornecedor);
            jtf_requisitante.setText(ctrl_req.mod_req.getRequisitado_por());
            jbt_editar.setEnabled(true);
            jdt_data.requestFocus();
            sql = "select * from requisicoes_desc where requisicao_cod='"+codreq+"'";
            preencherTabela(sql, jtb_desc);
            item_add = true;
        }
    }
    
    public void AtualizaTabela(){
        sql = "select * from requisicoes_desc where requisicao_cod='"+cod_requisicao+"'";
        preencherTabela(sql, jtb_desc);
    }
    
    public void BuscaNomeFornecdor(int cod){
        c_db.conecta();
        c_db.executaSQL("select * from fornecedores where codigo='"+cod+"'");
        try {
            if (c_db.rs.first()){
                nome_fornecedor = c_db.rs.getString("nome");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter Nome do Fornecedor. Cod Forn: "+cod+" Erro: "+ex);
        }
        c_db.desconecta();
    }
    
    public void ObtemListaUND(){
        c_db.conecta();
        try {
            c_db.executaSQL("select * from tipo_und order by tipo");
            if (c_db.rs.first()){
            jcb_und.removeAllItems();
            do{
                jcb_und.addItem(c_db.rs.getString("tipo"));
            } while (c_db.rs.next());
            }else{
                jcb_und.removeAllItems();
            jcb_und.addItem("UND");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Unidades de Medidas. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        c_db.desconecta();
    }
    
    
    public void ValidaCampos(){
        
        if (jdt_data.getDate()==null){
            JOptionPane.showMessageDialog(null, "Campo Data não pode estar vazio,\npor favor digite a data corretamente.");
            jdt_data.requestFocus();
        return;    
        }
        if (cod_fornecedor==0||nome_fornecedor==""){
            JOptionPane.showMessageDialog(null, "É necessário escolher um fornecedor,\ntente novamente.");
            jtf_fornecedor.requestFocus();
            jbt_pesquisar.requestFocus();
        return;
        }
        if (jtf_requisitante.getText().length()<=4){
            JOptionPane.showMessageDialog(null, "O Campo 'Requisitado por' não pode estar vazio, ou deve ser\npreenchido corretamente!\nPor favor digite o nome corretamente,\ntolerável 4 carecteres.");
            jtf_requisitante.requestFocus();
        return;
        }
        if (item_add==false){
            JOptionPane.showMessageDialog(null, "Você precisa adicionar pelo menos um item.\ntente novamente.");
            jtf_descriminacao.requestFocus();
            return;
        }
        
    }
    
    public boolean ValidaCamposDesc(){
        if (jtf_descriminacao.getText().length()<3){
            JOptionPane.showMessageDialog(null, "O Campo 'Discriminação' não pode estar vazio, ou deve ser\npreenchido corretamente!\nPor favor digite o nome corretamente,\ntolerável 3 carecteres.");
            jtf_descriminacao.requestFocus();
        return false;
        }
        if (Integer.valueOf(jtf_qtd.getText())<=0){
            JOptionPane.showMessageDialog(null, "O Campo 'Quantidade' não pode estar vazio, ou deve ser maior que zero!");
            jtf_qtd.requestFocus();
        return false;
        }
        return true;
    }
    
    public void SalvaRegistro(){
        ValidaCampos();
        mod_req.setCodigo(cod_requisicao);
        mod_req.setData(new java.sql.Date(jdt_data.getDate().getTime()));
        mod_req.setFornecedor_cod(cod_fornecedor);
        mod_req.setRequisitado_por(jtf_requisitante.getText());
        if (jcb_autorizar.getSelectedIndex()==1){
            mod_req.setAutorizado("SIM");
        }else{
            mod_req.setAutorizado("NÃO");
        }
        if (e_alteracao==false){
            mod_req.setAutorizado_por(FormPrincipal.UsuarioLogado);
        }else{
            mod_req.setAutorizado(autorizado_por);
        }
        mod_req.setAutorizado_por(FormPrincipal.UsuarioLogado);
        mod_req.setData_mod(new java.sql.Date(DataH.getTime()));
        mod_req.setMod_por(FormPrincipal.UsuarioLogado);
        
        if (ctrl_req.SalvaRegistro(mod_req, novo_cad)){
            mensagem = "Registro Salvo com sucesso.";
            LimpaItens();
            LimpaTabela();
            DesativaItens();
            jbt_novo.setEnabled(true);
            jbt_salvar.setEnabled(false);
            e_alteracao = false;
        }else{
            mensagem = "Houve um erro ao salvar o registro. \nDados técnicos do erro: "+ctrl_req.menssagem_erro;
        }
        JOptionPane.showMessageDialog(null, mensagem);
    }
    
    
    
    public void preencherTabela(String SQL, JTable jtb){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Discriminação","Tipo UND","Quant."}; //18 Campos
        c_db.conecta();
        c_db.executaSQL(SQL);
        try {
            if(c_db.rs.first()){
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{c_db.rs.getString("codigo"),                 //0
                                        c_db.rs.getString("discriminacao"),         //1
                                        c_db.rs.getString("tipo_und"),              //2
                                        c_db.rs.getString("qtd"),                   //3
                });
            }while(c_db.rs.next());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada. \n"
                    + "Erro: "+ex);
        }
        
        ModeloTabela m_tb = new ModeloTabela(dados, Colunas);
        jtb.setModel(m_tb);
        DefaultTableCellRenderer ali_D = new DefaultTableCellRenderer();
        ali_D.setHorizontalAlignment(SwingConstants.RIGHT);
        DefaultTableCellRenderer ali_C = new DefaultTableCellRenderer();
        ali_C.setHorizontalAlignment(SwingConstants.CENTER);
        jtb.getTableHeader().setPreferredSize(new Dimension(2920, 40));
        jtb.getColumnModel().getColumn(0).setPreferredWidth(80);
        jtb.getColumnModel().getColumn(0).setCellRenderer(ali_D);
        jtb.getColumnModel().getColumn(0).setResizable(false);
        jtb.getColumnModel().getColumn(1).setPreferredWidth(450);
        jtb.getColumnModel().getColumn(1).setResizable(false);
        jtb.getColumnModel().getColumn(2).setPreferredWidth(120);
        jtb.getColumnModel().getColumn(2).setResizable(false);
        jtb.getColumnModel().getColumn(3).setPreferredWidth(120);
        jtb.getColumnModel().getColumn(3).setResizable(false);
        jtb.getTableHeader().setReorderingAllowed(false);
        jtb.setAutoResizeMode(jtb.AUTO_RESIZE_OFF);
        jtb.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        c_db.desconecta();
    }
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PainelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jtf_codigo = new controle.JUpperField();
        jdt_data = new com.toedter.calendar.JDateChooser();
        jtf_fornecedor = new controle.JUpperField();
        jbt_pesquisar = new javax.swing.JButton();
        jtf_requisitante = new controle.JUpperField();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jtf_descriminacao = new controle.JUpperField();
        jcb_und = new javax.swing.JComboBox<>();
        jtf_qtd = new controle.JUpperField();
        jbt_rem = new javax.swing.JButton();
        jbt_add = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtb_desc = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        jcb_autorizar = new javax.swing.JComboBox<>();
        jbt_novo = new javax.swing.JButton();
        jbt_editar = new javax.swing.JButton();
        jbt_salvar = new javax.swing.JButton();
        jbt_excluir = new javax.swing.JButton();
        jbt_sair = new javax.swing.JButton();

        setIconifiable(true);
        setTitle("CADASTRO DE REQUISIÇÕES");
        getContentPane().setLayout(null);

        PainelFundo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PainelFundo.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Dados da Requisição:");
        PainelFundo.add(jLabel1);
        jLabel1.setBounds(10, 0, 790, 20);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Código:");
        PainelFundo.add(jLabel2);
        jLabel2.setBounds(10, 30, 120, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Data:");
        PainelFundo.add(jLabel3);
        jLabel3.setBounds(140, 30, 130, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Fornecedor:");
        PainelFundo.add(jLabel4);
        jLabel4.setBounds(280, 30, 500, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Requisitado por:");
        PainelFundo.add(jLabel5);
        jLabel5.setBounds(10, 80, 770, 20);
        PainelFundo.add(jtf_codigo);
        jtf_codigo.setBounds(10, 50, 120, 25);
        PainelFundo.add(jdt_data);
        jdt_data.setBounds(140, 50, 130, 25);
        PainelFundo.add(jtf_fornecedor);
        jtf_fornecedor.setBounds(280, 50, 470, 25);

        jbt_pesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jbt_pesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_pesquisarActionPerformed(evt);
            }
        });
        PainelFundo.add(jbt_pesquisar);
        jbt_pesquisar.setBounds(750, 50, 30, 25);
        PainelFundo.add(jtf_requisitante);
        jtf_requisitante.setBounds(10, 100, 770, 25);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel6.setText("Descrição da Requisição:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(10, 0, 760, 30);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel7.setText("Descriminação do item:");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(10, 30, 400, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel8.setText("Tipo UND:");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(420, 30, 140, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel9.setText("Quantidade:");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(570, 30, 120, 20);
        jPanel1.add(jtf_descriminacao);
        jtf_descriminacao.setBounds(10, 50, 400, 25);

        jcb_und.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(jcb_und);
        jcb_und.setBounds(420, 50, 140, 25);

        jtf_qtd.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_qtdKeyTyped(evt);
            }
        });
        jPanel1.add(jtf_qtd);
        jtf_qtd.setBounds(570, 50, 120, 25);

        jbt_rem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/edit_removeResultado.png"))); // NOI18N
        jbt_rem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_remActionPerformed(evt);
            }
        });
        jPanel1.add(jbt_rem);
        jbt_rem.setBounds(730, 50, 30, 25);

        jbt_add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/edit_addResultado.png"))); // NOI18N
        jbt_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_addActionPerformed(evt);
            }
        });
        jPanel1.add(jbt_add);
        jbt_add.setBounds(700, 50, 30, 25);

        PainelFundo.add(jPanel1);
        jPanel1.setBounds(10, 140, 770, 90);

        jtb_desc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jtb_desc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtb_descMouseClicked(evt);
            }
        });
        jtb_desc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtb_descKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jtb_desc);

        PainelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 240, 770, 170);

        getContentPane().add(PainelFundo);
        PainelFundo.setBounds(0, 0, 810, 420);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel10.setText("Selecione:");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(10, 430, 360, 18);

        jcb_autorizar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aguardando...", "Autorizar e imprimir Requisição..." }));
        getContentPane().add(jcb_autorizar);
        jcb_autorizar.setBounds(10, 450, 360, 25);

        jbt_novo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jbt_novo.setText("Novo");
        jbt_novo.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_novoActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_novo);
        jbt_novo.setBounds(380, 440, 80, 40);

        jbt_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jbt_editar.setText("Editar");
        jbt_editar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_editarActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_editar);
        jbt_editar.setBounds(460, 440, 80, 40);

        jbt_salvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jbt_salvar.setText("Salvar");
        jbt_salvar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_salvarActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_salvar);
        jbt_salvar.setBounds(540, 440, 80, 40);

        jbt_excluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jbt_excluir.setText("Excluir");
        jbt_excluir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_excluirActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_excluir);
        jbt_excluir.setBounds(620, 440, 80, 40);

        jbt_sair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jbt_sair.setText("Sair");
        jbt_sair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_sairActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_sair);
        jbt_sair.setBounds(700, 440, 80, 40);

        setBounds(0, 0, 799, 524);
    }// </editor-fold>//GEN-END:initComponents

    private void jbt_novoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_novoActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            LimpaItens();
            ctrl_req.NovoRegistro();
            cod_requisicao = ctrl_req.cod_requisicao;
            novo_cad = ctrl_req.novo_cad;
            Data = ctrl_req.Dagora;
            jtf_codigo.setText(String.valueOf(cod_requisicao));
            jbt_novo.setEnabled(false);
            jbt_salvar.setEnabled(true);
            AtivaItens();
            jdt_data.setDate(DataH);
            jtf_fornecedor.requestFocus();
            jbt_pesquisar.requestFocus();
        }else{

        }

    }//GEN-LAST:event_jbt_novoActionPerformed

    private void jbt_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_editarActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            AtivaItens();
            jbt_salvar.setEnabled(true);
            jbt_excluir.setEnabled(true);
            jtf_fornecedor.requestFocus();
            jbt_pesquisar.requestFocus();
        }else{

        }
    }//GEN-LAST:event_jbt_editarActionPerformed

    private void jbt_salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_salvarActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            SalvaRegistro();
            if (jcb_autorizar.getSelectedIndex()==1){
                ctrl_rel.Print_Requisicao(cod_requisicao);
            }
        }else{
        }
    }//GEN-LAST:event_jbt_salvarActionPerformed

    private void jbt_excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_excluirActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("excluir")){
            int i = JOptionPane.showConfirmDialog(null, "Deseja realizar a exclusão?.","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
            if(i == JOptionPane.YES_OPTION) {
                mod_req.setCodigo(cod_requisicao);
                ctrl_req.ExcluiRegistro(mod_req);
                LimpaItens();
                DesativaItens();
                jbt_excluir.setEnabled(false);
            }
        }else{

        }
    }//GEN-LAST:event_jbt_excluirActionPerformed

    private void jbt_sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_sairActionPerformed
        // TODO add your handling code here:
        if (a_form_ex==true){
            try {
                jifr.setIcon(false);
            } catch (PropertyVetoException ex) {

            }
        }
        this.dispose();
        FormPrincipal.AreaDeTrabalhoPrincipal.remove(this);
    }//GEN-LAST:event_jbt_sairActionPerformed

    private void jbt_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_addActionPerformed
        // TODO add your handling code here:
        if(ValidaCamposDesc()==true){
        mod_req_desc.setRequisicao_cod(cod_requisicao);
        mod_req_desc.setDescriminacao(jtf_descriminacao.getText());
        mod_req_desc.setTipo_und(String.valueOf(jcb_und.getSelectedItem()));
        int qtd = Integer.valueOf(jtf_qtd.getText());
        mod_req_desc.setQtd(qtd);
        if (ctrl_req.Add_item(mod_req_desc)){
            AtualizaTabela();
            LimpaItensDesc();
        }else{
            JOptionPane.showMessageDialog(null, ctrl_req.menssagem_erro);
        }
        }
        
    }//GEN-LAST:event_jbt_addActionPerformed

    private void jtf_qtdKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_qtdKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321,.";
            if(!caracteres.contains(evt.getKeyChar()+"")){
                evt.consume();
            }
    }//GEN-LAST:event_jtf_qtdKeyTyped

    private void jbt_remActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_remActionPerformed
        // TODO add your handling code here:
        mod_req_desc.setCodigo(idSel);
        ctrl_req.Rem_item(mod_req_desc);
        idSel = 0;
    }//GEN-LAST:event_jbt_remActionPerformed

    private void jtb_descMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtb_descMouseClicked
        // TODO add your handling code here:
        String sID = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 0));
        String sNome = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 1));
        String sUnd = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 2));
        String sQtd = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 3));
        idSel = Integer.parseInt(sID);
        jtf_descriminacao.setText(sNome);
        jcb_und.setSelectedItem(sUnd);
        jtf_qtd.setText(sQtd);
        
        
    }//GEN-LAST:event_jtb_descMouseClicked

    private void jtb_descKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtb_descKeyReleased
        // TODO add your handling code here:
            if (evt.getKeyCode()==KeyEvent.VK_UP || evt.getKeyCode()==KeyEvent.VK_DOWN){
            String sID = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 0));
            String sNome = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 1));
            String sUnd = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 2));
            String sQtd = ("" + jtb_desc.getValueAt(jtb_desc.getSelectedRow(), 3));
            idSel = Integer.parseInt(sID);
            jtf_descriminacao.setText(sNome);
            jcb_und.setSelectedItem(sUnd);
            jtf_qtd.setText(sQtd);
        }else if(evt.getKeyCode()==KeyEvent.VK_ENTER){

        }
    }//GEN-LAST:event_jtb_descKeyReleased

    private void jbt_pesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_pesquisarActionPerformed
        // TODO add your handling code here:
        DialogPesqForncecedor diag_forn = new DialogPesqForncecedor();
        diag_forn.setModal(true);
        diag_forn.setVisible(true);
        cod_fornecedor = 0;
        cod_fornecedor = diag_forn.CodFornecedor;
        nome_fornecedor = diag_forn.NomeFornecedor;
        jtf_fornecedor.setText(nome_fornecedor);
        
    }//GEN-LAST:event_jbt_pesquisarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PainelFundo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbt_add;
    private javax.swing.JButton jbt_editar;
    private javax.swing.JButton jbt_excluir;
    private javax.swing.JButton jbt_novo;
    private javax.swing.JButton jbt_pesquisar;
    private javax.swing.JButton jbt_rem;
    private javax.swing.JButton jbt_sair;
    private javax.swing.JButton jbt_salvar;
    private javax.swing.JComboBox<String> jcb_autorizar;
    private javax.swing.JComboBox<String> jcb_und;
    private com.toedter.calendar.JDateChooser jdt_data;
    private javax.swing.JTable jtb_desc;
    private controle.JUpperField jtf_codigo;
    private controle.JUpperField jtf_descriminacao;
    private controle.JUpperField jtf_fornecedor;
    private controle.JUpperField jtf_qtd;
    private controle.JUpperField jtf_requisitante;
    // End of variables declaration//GEN-END:variables
}
