/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package visual;

import controle.ControleFornecedor;
import controle.ValidaPermissaoUsuario;
import controle.gera_auditoria;
import controle.plano_fundo_forms;
import java.beans.PropertyVetoException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import modelo.ModeloFornecedor;

/**
 *
 * @author linde
 */
public class FormCadFornecedor extends javax.swing.JInternalFrame {
    //declara importações.
    ControleFornecedor ctrl_forn = new ControleFornecedor();
    ValidaPermissaoUsuario valida_peruser = new ValidaPermissaoUsuario();
    ModeloFornecedor mod = new ModeloFornecedor();
    gera_auditoria g_auditoria = new gera_auditoria();
    //declara variaveis
    public boolean a_form_ex = false; //identifica se o jormulario foi aberto a partir de outro formulario.
    public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.
    int cod_fornecedor;
    boolean novo_cad = false;
    String mensagem;
    public Date DataH = new Date();
    java.sql.Date Data;
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    java.sql.Date DataConvertidaSQL;
    /**
     * Creates new form FormCadFornecedor
     */
    public FormCadFornecedor() {
        initComponents();
        ColocaImagemFundoFrame();
        IniciaComp();
        LimpaItens();
        DesativaItens();
        
    }
    
    public void IniciaComp(){
        jtf_codigo.setEditable(false);
        jbt_novo.setEnabled(true);
        jbt_editar.setEnabled(false);
        jbt_excluir.setEnabled(false);
        jbt_salvar.setEnabled(false);
        jbt_sair.setEnabled(true);
    }
    
    public void LimpaItens(){
        jtf_codigo.setText("");
        jcb_tipo.setSelectedItem("PJ");
        jtf_nome.setText("");
        jtf_razao.setText("");
        jtf_cpf_cnpj.setText("");
        jtf_endereco.setText("");
        jtf_bairro.setText("");
        jtf_cidade.setText("");
        jcb_estado.setSelectedItem("BA");
        jtf_cep.setText("");
        jtf_fone.setText("");
        jtf_email.setText("");
        jtf_site.setText("");
        jtf_obs.setText("");
    }
    
    public void AtivaItens(){
        jtf_codigo.setEnabled(true);
        jcb_tipo.setEnabled(true);
        jtf_nome.setEnabled(true);
        jtf_razao.setEnabled(true);
        jtf_cpf_cnpj.setEnabled(true);
        jtf_endereco.setEnabled(true);
        jtf_bairro.setEnabled(true);
        jtf_cidade.setEnabled(true);
        jcb_estado.setEnabled(true);
        jtf_cep.setEnabled(true);
        jtf_fone.setEnabled(true);
        jtf_email.setEnabled(true);
        jtf_site.setEnabled(true);
        jtf_obs.setEnabled(true);
    }
    
    public void DesativaItens(){
        jtf_codigo.setEnabled(false);
        jcb_tipo.setEnabled(false);
        jtf_nome.setEnabled(false);
        jtf_razao.setEnabled(false);
        jtf_cpf_cnpj.setEnabled(false);
        jtf_endereco.setEnabled(false);
        jtf_bairro.setEnabled(false);
        jtf_cidade.setEnabled(false);
        jcb_estado.setEnabled(false);
        jtf_cep.setEnabled(false);
        jtf_fone.setEnabled(false);
        jtf_email.setEnabled(false);
        jtf_site.setEnabled(false);
        jtf_obs.setEnabled(false);
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        PainelFundo.setBorder(new plano_fundo_forms(AlturaForm, LarguraForm));
    }
    
    public void ValidaCampos(){
        if (jtf_nome.getText().length()<=4){
            JOptionPane.showMessageDialog(null, "Campo nome não pode estar vazio, ou deve ser\npreenchido corretamente!\nPor favor digite o nome corretamente,\ntolerável 4 carecteres.");
            jtf_nome.requestFocus();
            return;
        }
        
    }
    
    public void ObtemDadosFornecedor(int codfornecedor){
        if (codfornecedor!=0){
            cod_fornecedor = codfornecedor;
            ctrl_forn.ObterDadosFornecedor(codfornecedor);
            LimpaItens();
            jtf_codigo.setText(String.valueOf(ctrl_forn.mod_for.getCodigo()));
            jcb_tipo.setSelectedItem(ctrl_forn.mod_for.getTipo());
            jtf_nome.setText(ctrl_forn.mod_for.getNome());
            jtf_razao.setText(ctrl_forn.mod_for.getRazao_social());
            jtf_cpf_cnpj.setText(ctrl_forn.mod_for.getCpf_cnpj());
            jtf_endereco.setText(ctrl_forn.mod_for.getEndereco());
            jtf_bairro.setText(ctrl_forn.mod_for.getBairro());
            jtf_cidade.setText(ctrl_forn.mod_for.getCidade());
            jcb_estado.setSelectedItem(ctrl_forn.mod_for.getEstado());
            jtf_cep.setText(ctrl_forn.mod_for.getCep());
            jtf_fone.setText(ctrl_forn.mod_for.getTelefone());
            jtf_email.setText(ctrl_forn.mod_for.getEmail());
            jtf_site.setText(ctrl_forn.mod_for.getSite());
            jtf_obs.setText(ctrl_forn.mod_for.getObs());
            jbt_editar.setEnabled(true);
            jtf_nome.requestFocus();
        }
    }
    
    public void SalvaRegistro(){
        ValidaCampos();
        mod.setCodigo(cod_fornecedor);
        mod.setTipo(String.valueOf(jcb_tipo.getSelectedItem()));
        mod.setNome(jtf_nome.getText());
        mod.setRazao_social(jtf_razao.getText());
        mod.setCpf_cnpj(jtf_cpf_cnpj.getText());
        mod.setEndereco(jtf_endereco.getText());
        mod.setBairro(jtf_bairro.getText());
        mod.setCidade(jtf_cidade.getText());
        mod.setEstado(jcb_estado.getSelectedItem().toString());
        if (jtf_cep.getText().equals("     -   ")){mod.setCep("");}else{mod.setCep(jtf_cep.getText());}
        if (jtf_fone.getText().equals("(  )      -    ")){mod.setTelefone("");}else{mod.setTelefone(jtf_fone.getText());}
        mod.setEmail(jtf_email.getText());
        mod.setSite(jtf_site.getText());
        mod.setObs(jtf_obs.getText());
        mod.setData_mod(new java.sql.Date(DataH.getTime()));
        mod.setMod_por(FormPrincipal.UsuarioLogado);
        if (ctrl_forn.SalvaRegistro(mod, novo_cad)){
            mensagem = "Registro Salvo com sucesso.";
            LimpaItens();
            DesativaItens();
            jbt_novo.setEnabled(true);
        }else{
            mensagem = "Houve um erro ao salvar o registro. \nDados técnicos do erro: "+ctrl_forn.menssagem_erro;
        }
        JOptionPane.showMessageDialog(null, mensagem);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PainelFundo = new javax.swing.JPanel();
        jlb_cod = new javax.swing.JLabel();
        jlb_tipo = new javax.swing.JLabel();
        jlb_nome = new javax.swing.JLabel();
        jlb_razao = new javax.swing.JLabel();
        jlb_cpf = new javax.swing.JLabel();
        jlb_end = new javax.swing.JLabel();
        jlb_bairro = new javax.swing.JLabel();
        jlb_cidade = new javax.swing.JLabel();
        jlb_estado = new javax.swing.JLabel();
        jlb_cep = new javax.swing.JLabel();
        jlb_tel = new javax.swing.JLabel();
        jlb_email = new javax.swing.JLabel();
        jlb_site = new javax.swing.JLabel();
        jlb_obs = new javax.swing.JLabel();
        jtf_codigo = new controle.JUpperField();
        jcb_tipo = new javax.swing.JComboBox<>();
        jtf_nome = new controle.JUpperField();
        jtf_razao = new controle.JUpperField();
        jtf_cpf_cnpj = new controle.JUpperField();
        jtf_endereco = new controle.JUpperField();
        jtf_bairro = new controle.JUpperField();
        jtf_cidade = new controle.JUpperField();
        jcb_estado = new javax.swing.JComboBox<>();
        jtf_cep = new controle.JUpperField();
        jtf_fone = new controle.JUpperField();
        jtf_email = new javax.swing.JTextField();
        jtf_site = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtf_obs = new controle.JUpperFieldTextArea();
        jbt_sair = new javax.swing.JButton();
        jbt_novo = new javax.swing.JButton();
        jbt_salvar = new javax.swing.JButton();
        jbt_editar = new javax.swing.JButton();
        jbt_excluir = new javax.swing.JButton();

        setIconifiable(true);
        setTitle("CADASTRO DE FORNECEDOR");
        getContentPane().setLayout(null);

        PainelFundo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PainelFundo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlb_cod.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_cod.setForeground(new java.awt.Color(255, 255, 255));
        jlb_cod.setText("Código:");
        PainelFundo.add(jlb_cod, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 70, 20));

        jlb_tipo.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_tipo.setForeground(new java.awt.Color(255, 255, 255));
        jlb_tipo.setText("Tipo:");
        PainelFundo.add(jlb_tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 90, 20));

        jlb_nome.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_nome.setForeground(new java.awt.Color(255, 255, 255));
        jlb_nome.setText("Nome / Nome Fantasia:");
        PainelFundo.add(jlb_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 500, 20));

        jlb_razao.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_razao.setForeground(new java.awt.Color(255, 255, 255));
        jlb_razao.setText("Razão Social:");
        PainelFundo.add(jlb_razao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 460, 20));

        jlb_cpf.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_cpf.setForeground(new java.awt.Color(255, 255, 255));
        jlb_cpf.setText("CPF / CNPJ:");
        PainelFundo.add(jlb_cpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 60, 210, 20));

        jlb_end.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_end.setForeground(new java.awt.Color(255, 255, 255));
        jlb_end.setText("Endereço:");
        PainelFundo.add(jlb_end, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 450, 20));

        jlb_bairro.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_bairro.setForeground(new java.awt.Color(255, 255, 255));
        jlb_bairro.setText("Bairro:");
        PainelFundo.add(jlb_bairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 110, 220, 20));

        jlb_cidade.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_cidade.setForeground(new java.awt.Color(255, 255, 255));
        jlb_cidade.setText("Cidade:");
        PainelFundo.add(jlb_cidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 380, 20));

        jlb_estado.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_estado.setForeground(new java.awt.Color(255, 255, 255));
        jlb_estado.setText("Estado:");
        PainelFundo.add(jlb_estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 120, 20));

        jlb_cep.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_cep.setForeground(new java.awt.Color(255, 255, 255));
        jlb_cep.setText("Cep:");
        PainelFundo.add(jlb_cep, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 160, 160, 20));

        jlb_tel.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_tel.setForeground(new java.awt.Color(255, 255, 255));
        jlb_tel.setText("Telefone:");
        PainelFundo.add(jlb_tel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 140, 20));

        jlb_email.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_email.setForeground(new java.awt.Color(255, 255, 255));
        jlb_email.setText("E-mail:");
        PainelFundo.add(jlb_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 250, 20));

        jlb_site.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_site.setForeground(new java.awt.Color(255, 255, 255));
        jlb_site.setText("Site:");
        PainelFundo.add(jlb_site, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 210, 270, 20));

        jlb_obs.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jlb_obs.setForeground(new java.awt.Color(255, 255, 255));
        jlb_obs.setText("Observações:");
        PainelFundo.add(jlb_obs, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 680, 20));
        PainelFundo.add(jtf_codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 70, -1));

        jcb_tipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PF", "PJ" }));
        jcb_tipo.setSelectedIndex(1);
        jcb_tipo.setToolTipText("");
        PainelFundo.add(jcb_tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, 90, -1));
        PainelFundo.add(jtf_nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 30, 500, -1));
        PainelFundo.add(jtf_razao, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 460, -1));
        PainelFundo.add(jtf_cpf_cnpj, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, 210, -1));
        PainelFundo.add(jtf_endereco, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 450, -1));
        PainelFundo.add(jtf_bairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 130, 220, -1));
        PainelFundo.add(jtf_cidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 380, -1));

        jcb_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "SC", "SE", "SP", "TO" }));
        PainelFundo.add(jcb_estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 120, -1));
        PainelFundo.add(jtf_cep, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 180, 160, -1));
        PainelFundo.add(jtf_fone, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 140, -1));
        PainelFundo.add(jtf_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 250, -1));
        PainelFundo.add(jtf_site, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 230, 270, -1));

        jtf_obs.setColumns(20);
        jtf_obs.setRows(5);
        jScrollPane1.setViewportView(jtf_obs);

        PainelFundo.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 680, 80));

        getContentPane().add(PainelFundo);
        PainelFundo.setBounds(10, 10, 700, 370);

        jbt_sair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jbt_sair.setText("Sair");
        jbt_sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_sairActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_sair);
        jbt_sair.setBounds(620, 390, 90, 40);

        jbt_novo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jbt_novo.setText("Novo");
        jbt_novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_novoActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_novo);
        jbt_novo.setBounds(260, 390, 90, 40);

        jbt_salvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jbt_salvar.setText("Salvar");
        jbt_salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_salvarActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_salvar);
        jbt_salvar.setBounds(440, 390, 90, 40);

        jbt_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jbt_editar.setText("Editar");
        jbt_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_editarActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_editar);
        jbt_editar.setBounds(350, 390, 90, 40);

        jbt_excluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jbt_excluir.setText("Excluir");
        jbt_excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_excluirActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_excluir);
        jbt_excluir.setBounds(530, 390, 90, 40);

        setBounds(0, 0, 735, 480);
    }// </editor-fold>//GEN-END:initComponents

    private void jbt_novoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_novoActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            LimpaItens();
            ctrl_forn.NovoRegistro();
            cod_fornecedor = ctrl_forn.cod_fornecedor;
            novo_cad = ctrl_forn.novo_cad;
            Data = ctrl_forn.Dagora;
            jtf_codigo.setText(String.valueOf(cod_fornecedor));
            jbt_novo.setEnabled(false);
            jbt_salvar.setEnabled(true);
            AtivaItens();
            jtf_nome.requestFocus();
        }else{
            
        }
        
    }//GEN-LAST:event_jbt_novoActionPerformed

    private void jbt_salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_salvarActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            SalvaRegistro();
        }else{
        }
    }//GEN-LAST:event_jbt_salvarActionPerformed

    private void jbt_sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_sairActionPerformed
        // TODO add your handling code here:
        if (a_form_ex==true){
            try {
                jifr.setIcon(false);
            } catch (PropertyVetoException ex) {
                
            }
        }
        this.dispose();
        FormPrincipal.AreaDeTrabalhoPrincipal.remove(this);
    }//GEN-LAST:event_jbt_sairActionPerformed

    private void jbt_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_editarActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            AtivaItens();
            jbt_salvar.setEnabled(true);
            jbt_excluir.setEnabled(true);
            jtf_nome.requestFocus();
        }else{
             
        }
    }//GEN-LAST:event_jbt_editarActionPerformed

    private void jbt_excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_excluirActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("excluir")){
            int i = JOptionPane.showConfirmDialog(null, "Deseja realizar a exclusão?.","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                    mod.setCodigo(cod_fornecedor);
                    ctrl_forn.ExcluiRegistro(mod);
                    if (a_form_ex==true){
                        try {
                            jifr.setIcon(false);
                        } catch (PropertyVetoException ex) {

                        }
                    }
                    this.dispose();
                    FormPrincipal.AreaDeTrabalhoPrincipal.remove(this);
                    }
        }else{
  
        }
    }//GEN-LAST:event_jbt_excluirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PainelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbt_editar;
    private javax.swing.JButton jbt_excluir;
    private javax.swing.JButton jbt_novo;
    private javax.swing.JButton jbt_sair;
    private javax.swing.JButton jbt_salvar;
    private javax.swing.JComboBox<String> jcb_estado;
    private javax.swing.JComboBox<String> jcb_tipo;
    private javax.swing.JLabel jlb_bairro;
    private javax.swing.JLabel jlb_cep;
    private javax.swing.JLabel jlb_cidade;
    private javax.swing.JLabel jlb_cod;
    private javax.swing.JLabel jlb_cpf;
    private javax.swing.JLabel jlb_email;
    private javax.swing.JLabel jlb_end;
    private javax.swing.JLabel jlb_estado;
    private javax.swing.JLabel jlb_nome;
    private javax.swing.JLabel jlb_obs;
    private javax.swing.JLabel jlb_razao;
    private javax.swing.JLabel jlb_site;
    private javax.swing.JLabel jlb_tel;
    private javax.swing.JLabel jlb_tipo;
    private controle.JUpperField jtf_bairro;
    private controle.JUpperField jtf_cep;
    private controle.JUpperField jtf_cidade;
    private controle.JUpperField jtf_codigo;
    private controle.JUpperField jtf_cpf_cnpj;
    private javax.swing.JTextField jtf_email;
    private controle.JUpperField jtf_endereco;
    private controle.JUpperField jtf_fone;
    private controle.JUpperField jtf_nome;
    private controle.JUpperFieldTextArea jtf_obs;
    private controle.JUpperField jtf_razao;
    private javax.swing.JTextField jtf_site;
    // End of variables declaration//GEN-END:variables
}
