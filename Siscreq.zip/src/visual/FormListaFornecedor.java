/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package visual;

import controle.ConectaBanco;
import controle.ControleFornecedor;
import controle.ValidaPermissaoUsuario;
import controle.formata_janelas;
import controle.plano_fundo_forms;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.beans.PropertyVetoException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import modelo.ModeloFornecedor;
import modelo.ModeloTabela;
import static visual.FormPrincipal.AreaDeTrabalhoPrincipal;

/**
 *
 * @author linde
 */
public class FormListaFornecedor extends javax.swing.JInternalFrame {
    //Declara importações:
    ConectaBanco c_db = new ConectaBanco();
    formata_janelas visual_form = new formata_janelas();
    ValidaPermissaoUsuario valida_peruser = new ValidaPermissaoUsuario();
    ControleFornecedor ctrl_forn = new ControleFornecedor();
    ModeloFornecedor mod_forn = new ModeloFornecedor();
    
    //declara variáveis:
    String sql = "";
    String dt_form_pesq = "";
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    int idSel = 0;
    
    /**
     * Creates new form FormListaFornecedor
     */
    public FormListaFornecedor() {
        initComponents();
        ColocaImagemFundoFrame();
        Pesquisaini();
        DesativaItens();
    }
    
    public void AtivaItens(){
        jbt_abrir.setEnabled(true);
        jbt_excluir.setEnabled(true);
    }
    
    public void DesativaItens(){
        jbt_abrir.setEnabled(false);
        jbt_excluir.setEnabled(false);
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        PainelFundo.setBorder(new plano_fundo_forms(AlturaForm, LarguraForm));
    }
    
    public void preencherTabela(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Tipo","Nome","Razão", "CPF/CNPJ","Endereço","Bairro","Cidade","Estado","Cep", 
            "Telefone","E-mail","Site","Obs","<html><center>Data<br>Cadastro</html>","<html><center>Cadastrado<br>Por</html>",
            "<html><center>Data<br>Modificação</html>", "<html><center>Modificado<br>Por</html>" }; //18 Campos
        c_db.conecta();
        c_db.executaSQL(SQL);
        
        String dt_cad="", dt_mod="";
        
        
        try {
            if(c_db.rs.first()){
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            
            do{
                
                if (c_db.rs.getDate("data_cad")!=null){dt_cad = df.format(c_db.rs.getDate("data_cad"));}
                if (c_db.rs.getDate("data_mod")!=null){dt_cad = df.format(c_db.rs.getDate("data_mod"));}
                
                dados.add(new Object[]{c_db.rs.getString("codigo"),                 //0
                                        c_db.rs.getString("tipo"),                  //1
                                        c_db.rs.getString("nome"),                  //2
                                        c_db.rs.getString("razao_social"),          //3
                                        c_db.rs.getString("cpf_cnpj"),              //4
                                        c_db.rs.getString("endereco"),              //5
                                        c_db.rs.getString("bairro"),                //6
                                        c_db.rs.getString("cidade"),                //7
                                        c_db.rs.getString("estado"),                //8 
                                        c_db.rs.getString("cep"),                   //9 
                                        c_db.rs.getString("telefone"),              //10
                                        c_db.rs.getString("email"),                 //11
                                        c_db.rs.getString("site"),                  //12
                                        c_db.rs.getString("obs"),                   //13
                                        dt_cad,                                               //14
                                        c_db.rs.getString("cad_por"),               //15
                                        dt_mod,                                               //16
                                        c_db.rs.getString("mod_por"),               //17
                });
            }while(c_db.rs.next());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada. \n"
                    + "Erro: "+ex);
        }
        
        ModeloTabela m_tb = new ModeloTabela(dados, Colunas);
        jtb_listagem.setModel(m_tb);
        DefaultTableCellRenderer ali_D = new DefaultTableCellRenderer();
        ali_D.setHorizontalAlignment(SwingConstants.RIGHT);
        DefaultTableCellRenderer ali_C = new DefaultTableCellRenderer();
        ali_C.setHorizontalAlignment(SwingConstants.CENTER);
        jtb_listagem.getTableHeader().setPreferredSize(new Dimension(2920, 40));
        jtb_listagem.getColumnModel().getColumn(0).setPreferredWidth(60);
        jtb_listagem.getColumnModel().getColumn(0).setCellRenderer(ali_D);
        jtb_listagem.getColumnModel().getColumn(0).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(1).setPreferredWidth(60);
        jtb_listagem.getColumnModel().getColumn(1).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(2).setPreferredWidth(200);
        jtb_listagem.getColumnModel().getColumn(2).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(3).setPreferredWidth(200);
        jtb_listagem.getColumnModel().getColumn(3).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(4).setPreferredWidth(100);
        jtb_listagem.getColumnModel().getColumn(4).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(5).setPreferredWidth(300);
        jtb_listagem.getColumnModel().getColumn(5).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(6).setPreferredWidth(120);
        jtb_listagem.getColumnModel().getColumn(6).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(7).setPreferredWidth(120);
        jtb_listagem.getColumnModel().getColumn(7).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(8).setPreferredWidth(80);
        jtb_listagem.getColumnModel().getColumn(8).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(9).setPreferredWidth(80);
        jtb_listagem.getColumnModel().getColumn(9).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(10).setPreferredWidth(80);
        jtb_listagem.getColumnModel().getColumn(10).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(11).setPreferredWidth(120);
        jtb_listagem.getColumnModel().getColumn(11).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(12).setPreferredWidth(120);
        jtb_listagem.getColumnModel().getColumn(12).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(12).setCellRenderer(ali_C);
        jtb_listagem.getColumnModel().getColumn(13).setPreferredWidth(200);
        jtb_listagem.getColumnModel().getColumn(13).setCellRenderer(ali_C);
        jtb_listagem.getColumnModel().getColumn(13).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(14).setPreferredWidth(80);
        jtb_listagem.getColumnModel().getColumn(14).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(15).setPreferredWidth(100);
        jtb_listagem.getColumnModel().getColumn(15).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(16).setPreferredWidth(80);
        jtb_listagem.getColumnModel().getColumn(16).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(17).setPreferredWidth(100);
        jtb_listagem.getColumnModel().getColumn(17).setResizable(false);
        jtb_listagem.getTableHeader().setReorderingAllowed(false);
        jtb_listagem.setAutoResizeMode(jtb_listagem.AUTO_RESIZE_OFF);
        jtb_listagem.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        c_db.desconecta();
    }
    
    private void AcaoAoteclarEnter() {
        jtb_listagem.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "Enter");
        jtb_listagem.getActionMap().put("Enter", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                AbreComEnter();
            }
        });
    }
    
    public void AbreComEnter(){
        FormCadFornecedor frm_cadFornecedor = new FormCadFornecedor();
        frm_cadFornecedor.a_form_ex = true;
        frm_cadFornecedor.ObtemDadosFornecedor(idSel);
        AbreNovaJanela(frm_cadFornecedor);
        try {
            this.setIcon(true);
        } catch (PropertyVetoException ex) {
            
        }
    }
    
    public void Pesquisaini(){
        sql = "select * from fornecedores order by nome";
        preencherTabela(sql);
        jcb_pesquisa.setSelectedIndex(1);
    }
    
    public void AbreNovaJanela(JInternalFrame jif){
        visual_form.AbreNovaJanelaInterna(jif, AreaDeTrabalhoPrincipal);
    }
    
    public void Pesquisar(){
    //Codigo              0
    //Nome / N. Fantasia  1
    //CPF / CNPJ          2
    //Data de Cadastro    3
    //Cadastrador por     4
        sql = "select * from fornecedores ";
        String DadosParaPesquisar = jtf_pesquisa.getText();
        String CampoPesquisa = "";
        int CampoEscolhido = (jcb_pesquisa.getSelectedIndex());
        if (CampoEscolhido == 0){
            if ("".equals(jtf_pesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite um número para a pesquisa.");
            }else{
                int codpesq = Integer.parseInt(DadosParaPesquisar);

                CampoPesquisa = "where codigo='"+codpesq+"'";
            }
        }
        else if (CampoEscolhido == 1){CampoPesquisa = "where nome like '"+DadosParaPesquisar+"%'";}
        else if (CampoEscolhido == 2){CampoPesquisa = "where cpf_cnpj like '"+DadosParaPesquisar+"%'";}
        else if (CampoEscolhido == 3){
            obtemformatodata(DadosParaPesquisar);
            CampoPesquisa = "where dt_cad >= #"+dt_form_pesq+"# order by dt_cad";
        }
        else if (CampoEscolhido == 4){CampoPesquisa = "where cad_por like '"+DadosParaPesquisar+"%'";}
        preencherTabela(sql+CampoPesquisa);
        jtf_pesquisa.requestFocus();
    }
    
    public void obtemformatodata (String Data){
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        dt_form_pesq = ano+"-"+mes+"-"+dia+" 00:00:00";
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PainelFundo = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jcb_pesquisa = new javax.swing.JComboBox<>();
        jtf_pesquisa = new controle.JUpperField();
        jbt_pesquisar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtb_listagem = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jlb_1 = new javax.swing.JLabel();
        jlb_2 = new javax.swing.JLabel();
        jlb_3 = new javax.swing.JLabel();
        jbt_novo = new javax.swing.JButton();
        jbt_abrir = new javax.swing.JButton();
        jbt_excluir = new javax.swing.JButton();
        jbt_sair = new javax.swing.JButton();

        setIconifiable(true);
        setTitle("LISTAGEM DE FORNECEDORES");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
                atualiza_dados(evt);
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });
        getContentPane().setLayout(null);

        PainelFundo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PainelFundo.setLayout(null);

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setLayout(null);

        jLabel1.setText("Método de pesquisa:");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(10, 10, 200, 20);

        jLabel2.setText("Contéudo:");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(220, 10, 550, 20);

        jcb_pesquisa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Codigo", "Nome / N. Fantasia", "CPF / CNPJ", "Data de Cadastro", "Cadastrador por" }));
        jPanel2.add(jcb_pesquisa);
        jcb_pesquisa.setBounds(10, 30, 200, 30);

        jtf_pesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtf_pesquisaKeyReleased(evt);
            }
        });
        jPanel2.add(jtf_pesquisa);
        jtf_pesquisa.setBounds(220, 30, 550, 30);

        jbt_pesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jbt_pesquisar.setMargin(new java.awt.Insets(1, 1, 1, 1));
        jbt_pesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_pesquisarActionPerformed(evt);
            }
        });
        jPanel2.add(jbt_pesquisar);
        jbt_pesquisar.setBounds(770, 30, 40, 30);

        PainelFundo.add(jPanel2);
        jPanel2.setBounds(10, 10, 820, 70);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jtb_listagem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jtb_listagem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtb_listagemMouseClicked(evt);
            }
        });
        jtb_listagem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtb_listagemKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jtb_listagem);

        PainelFundo.add(jScrollPane2);
        jScrollPane2.setBounds(10, 90, 820, 310);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(null);

        jlb_1.setText("  Cadastro selecionado:");
        jPanel3.add(jlb_1);
        jlb_1.setBounds(0, 0, 400, 20);
        jPanel3.add(jlb_2);
        jlb_2.setBounds(0, 20, 400, 25);
        jPanel3.add(jlb_3);
        jlb_3.setBounds(0, 50, 400, 25);

        jbt_novo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/add.png"))); // NOI18N
        jbt_novo.setText("Novo");
        jbt_novo.setMargin(new java.awt.Insets(1, 1, 1, 1));
        jbt_novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_novoActionPerformed(evt);
            }
        });
        jPanel3.add(jbt_novo);
        jbt_novo.setBounds(410, 10, 100, 60);

        jbt_abrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/open folderResultado.png"))); // NOI18N
        jbt_abrir.setText("Abrir");
        jbt_abrir.setMargin(new java.awt.Insets(1, 1, 1, 1));
        jbt_abrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_abrirActionPerformed(evt);
            }
        });
        jPanel3.add(jbt_abrir);
        jbt_abrir.setBounds(510, 10, 100, 60);

        jbt_excluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/remove.png"))); // NOI18N
        jbt_excluir.setText("Excluir");
        jbt_excluir.setToolTipText("");
        jbt_excluir.setMargin(new java.awt.Insets(1, 1, 1, 1));
        jbt_excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_excluirActionPerformed(evt);
            }
        });
        jPanel3.add(jbt_excluir);
        jbt_excluir.setBounds(610, 10, 100, 60);

        jbt_sair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/exit_PNG36.png"))); // NOI18N
        jbt_sair.setText("Sair");
        jbt_sair.setMargin(new java.awt.Insets(1, 1, 1, 1));
        jbt_sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_sairActionPerformed(evt);
            }
        });
        jPanel3.add(jbt_sair);
        jbt_sair.setBounds(710, 10, 100, 60);

        PainelFundo.add(jPanel3);
        jPanel3.setBounds(10, 410, 820, 80);

        getContentPane().add(PainelFundo);
        PainelFundo.setBounds(0, 0, 850, 510);

        setBounds(0, 0, 853, 537);
    }// </editor-fold>//GEN-END:initComponents

    private void jtf_pesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_pesquisaKeyReleased
        Pesquisar();
    }//GEN-LAST:event_jtf_pesquisaKeyReleased

    private void jbt_pesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_pesquisarActionPerformed
        Pesquisar();
    }//GEN-LAST:event_jbt_pesquisarActionPerformed

    private void jbt_novoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_novoActionPerformed

        FormCadFornecedor frm_fornecedores = new FormCadFornecedor();
        frm_fornecedores.a_form_ex = true;
        frm_fornecedores.jifr = this;
        AbreNovaJanela(frm_fornecedores);
        try {
            this.setIcon(true);
        } catch (PropertyVetoException ex) {

        }

    }//GEN-LAST:event_jbt_novoActionPerformed

    private void jbt_abrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_abrirActionPerformed

        FormCadFornecedor frm_fornecedores = new FormCadFornecedor();
        frm_fornecedores.a_form_ex = true;
        frm_fornecedores.jifr = this;
        frm_fornecedores.ObtemDadosFornecedor(idSel);
        AbreNovaJanela(frm_fornecedores);
        try {
            this.setIcon(true);
        } catch (PropertyVetoException ex) {

        }

    }//GEN-LAST:event_jbt_abrirActionPerformed

    private void jbt_excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_excluirActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("excluir")){
            int i = JOptionPane.showConfirmDialog(null, "Deseja realizar a exclusão?.","Confirmando Exclusão", JOptionPane.YES_NO_OPTION,2);
            if(i == JOptionPane.YES_OPTION) {
                mod_forn.setCodigo(idSel);
                ctrl_forn.ExcluiRegistro(mod_forn);
                Pesquisaini();
            }else{
            }
        }else{
        
        }
    }//GEN-LAST:event_jbt_excluirActionPerformed

    private void jbt_sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_sairActionPerformed
        this.dispose();
        FormPrincipal.AreaDeTrabalhoPrincipal.remove(this);
    }//GEN-LAST:event_jbt_sairActionPerformed

    private void jtb_listagemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtb_listagemMouseClicked
        String sID = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 0));
        String sNome = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 2));
        idSel = Integer.parseInt(sID);
        jlb_2.setText("   Código: "+idSel);
        jlb_3.setText("   Nome: "+sNome);
        AtivaItens();
    }//GEN-LAST:event_jtb_listagemMouseClicked

    private void jtb_listagemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtb_listagemKeyReleased
        if (evt.getKeyCode()==KeyEvent.VK_UP || evt.getKeyCode()==KeyEvent.VK_DOWN){
            String cod_forn = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 0));
            String sNome = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 2));
            idSel = Integer.parseInt(cod_forn);
            jlb_2.setText("   Código: "+idSel);
            jlb_3.setText("   Nome: "+sNome);
            AtivaItens();
        }else if(evt.getKeyCode()==KeyEvent.VK_ENTER){

        }
    }//GEN-LAST:event_jtb_listagemKeyReleased

    private void atualiza_dados(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_atualiza_dados
        // TODO add your handling code here:
        Pesquisaini();
    }//GEN-LAST:event_atualiza_dados


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PainelFundo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jbt_abrir;
    private javax.swing.JButton jbt_excluir;
    private javax.swing.JButton jbt_novo;
    private javax.swing.JButton jbt_pesquisar;
    private javax.swing.JButton jbt_sair;
    private javax.swing.JComboBox<String> jcb_pesquisa;
    private javax.swing.JLabel jlb_1;
    private javax.swing.JLabel jlb_2;
    private javax.swing.JLabel jlb_3;
    private javax.swing.JTable jtb_listagem;
    private controle.JUpperField jtf_pesquisa;
    // End of variables declaration//GEN-END:variables
}
