/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.plano_fundo_forms;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import modelo.ModeloTabela;

/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */
    public class DialogPesqForncecedor extends javax.swing.JDialog {
    ConectaBanco c_db = new ConectaBanco();
    public int CodFornecedor = 0;
    public String NomeFornecedor = null;
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    
    /**
     * Creates new form DialogPesqCliente
     */
    public DialogPesqForncecedor() {
        
        initComponents();
        preencherTablePesquisaOS("select * from fornecedores order by codigo desc");
        ColocaImagemFundoFrame();
        
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        PainelFundo.setBorder(new plano_fundo_forms(AlturaForm, LarguraForm));
    }

    private DialogPesqForncecedor(JFrame jFrame, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public int GetCodigoCliente (){
            
        CodFornecedor = Integer.parseInt("" + jtb_pesquisa.getValueAt(jtb_pesquisa.getSelectedRow(), 0));
        
        return CodFornecedor;
         
    }

    
    public String GetNomeCliente (){
            
        NomeFornecedor = "" + jtb_pesquisa.getValueAt(jtb_pesquisa.getSelectedRow(), 1);
        
        return NomeFornecedor;
    }
    
    
    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Tipo","Nome","Razão","CPF / CNPJ","Endereço","Bairro","Cidade", "Telefone", "Dt. Cadastro"};
        c_db.conecta();
        c_db.executaSQL(SQL);
        String dt_cad="", dt_mod="";
        
        try {
            if (c_db.rs.first()){
                do{
                if (c_db.rs.getDate("data_cad")!=null){dt_cad = df.format(c_db.rs.getDate("data_cad"));}
                dados.add(new Object[]{
                    c_db.rs.getString("codigo"),            //0
                    c_db.rs.getString("tipo"),              //1
                    c_db.rs.getString("nome"),              //2
                    c_db.rs.getString("razao_social"),      //3
                    c_db.rs.getString("cpf_cnpj"),          //4
                    c_db.rs.getString("endereco"),          //5
                    c_db.rs.getString("bairro"),            //6
                    c_db.rs.getString("cidade"),            //7
                    c_db.rs.getString("telefone"),          //8
                    dt_cad});                                         //9
                }while(c_db.rs.next());
            }
            
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane, ex.toString());
        }
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jtb_pesquisa.setModel(modelo);
        jtb_pesquisa.getColumnModel().getColumn(0).setPreferredWidth(60);
        jtb_pesquisa.getColumnModel().getColumn(0).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(1).setPreferredWidth(60);
        jtb_pesquisa.getColumnModel().getColumn(1).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(2).setPreferredWidth(250);
        jtb_pesquisa.getColumnModel().getColumn(2).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(3).setPreferredWidth(250);
        jtb_pesquisa.getColumnModel().getColumn(3).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(4).setPreferredWidth(100);
        jtb_pesquisa.getColumnModel().getColumn(4).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(5).setPreferredWidth(300);
        jtb_pesquisa.getColumnModel().getColumn(5).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(6).setPreferredWidth(150);
        jtb_pesquisa.getColumnModel().getColumn(6).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(7).setPreferredWidth(150);
        jtb_pesquisa.getColumnModel().getColumn(7).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(8).setPreferredWidth(100);
        jtb_pesquisa.getColumnModel().getColumn(8).setResizable(false);
        jtb_pesquisa.getColumnModel().getColumn(9).setPreferredWidth(80);
        jtb_pesquisa.getColumnModel().getColumn(9).setResizable(false);
        jtb_pesquisa.getTableHeader().setReorderingAllowed(false);
        jtb_pesquisa.setAutoResizeMode(jtb_pesquisa.AUTO_RESIZE_OFF);
        jtb_pesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        c_db.desconecta();
              
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PainelFundo = new javax.swing.JPanel();
        jbt_pesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtb_pesquisa = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jtf_pesquisa = new controle.JUpperField();
        jbt_sair = new javax.swing.JButton();
        jbt_ok = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PESQUISA");
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(null);

        PainelFundo.setBackground(new java.awt.Color(0, 153, 255));
        PainelFundo.setLayout(null);

        jbt_pesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jbt_pesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_pesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_pesquisarActionPerformed(evt);
            }
        });
        PainelFundo.add(jbt_pesquisar);
        jbt_pesquisar.setBounds(650, 29, 50, 28);

        jtb_pesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jtb_pesquisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtb_pesquisaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtb_pesquisa);

        PainelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 690, 370);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        PainelFundo.add(jLabel2);
        jLabel2.setBounds(10, 10, 690, 14);

        jtf_pesquisa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jtf_pesquisa.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                jtf_pesquisaAncestorMoved(evt);
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jtf_pesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtf_pesquisaKeyReleased(evt);
            }
        });
        PainelFundo.add(jtf_pesquisa);
        jtf_pesquisa.setBounds(10, 30, 640, 25);

        getContentPane().add(PainelFundo);
        PainelFundo.setBounds(10, 20, 710, 450);

        jbt_sair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jbt_sair.setText("Sair");
        jbt_sair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_sairActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_sair);
        jbt_sair.setBounds(630, 480, 90, 40);

        jbt_ok.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jbt_ok.setText("OK");
        jbt_ok.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbt_ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_okActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_ok);
        jbt_ok.setBounds(540, 480, 90, 40);

        setSize(new java.awt.Dimension(746, 569));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbt_pesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_pesquisarActionPerformed
      
        preencherTablePesquisaOS("select * from clientes where nome like '"+jtf_pesquisa.getText()+"%'");
        
    }//GEN-LAST:event_jbt_pesquisarActionPerformed

    private void jtb_pesquisaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtb_pesquisaMouseClicked
        if (evt.getClickCount()==2){
            
            CodFornecedor = Integer.parseInt("" + jtb_pesquisa.getValueAt(jtb_pesquisa.getSelectedRow(), 0));
            NomeFornecedor = "" + jtb_pesquisa.getValueAt(jtb_pesquisa.getSelectedRow(), 1);
            
            dispose();
        }

    }//GEN-LAST:event_jtb_pesquisaMouseClicked

    private void jTextFieldCampoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldCampoPesquisaActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased

        preencherTablePesquisaOS("select * from fornecedores where nome like '"+jtf_pesquisa.getText()+"%'");

    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased

    private void jbt_sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_sairActionPerformed
        dispose();
    }//GEN-LAST:event_jbt_sairActionPerformed

    private void jbt_okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_okActionPerformed

        CodFornecedor = Integer.parseInt("" + jtb_pesquisa.getValueAt(jtb_pesquisa.getSelectedRow(), 0));
        NomeFornecedor = "" + jtb_pesquisa.getValueAt(jtb_pesquisa.getSelectedRow(), 1);
        
        dispose();

    }//GEN-LAST:event_jbt_okActionPerformed

    private void jtf_pesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_pesquisaKeyReleased
        // TODO add your handling code here:
        preencherTablePesquisaOS("select * from clientes where nome like '"+jtf_pesquisa.getText()+"%'");
    }//GEN-LAST:event_jtf_pesquisaKeyReleased

    private void jtf_pesquisaAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jtf_pesquisaAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_jtf_pesquisaAncestorMoved

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DialogPesqForncecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DialogPesqForncecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DialogPesqForncecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DialogPesqForncecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DialogPesqForncecedor dialog = new DialogPesqForncecedor(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PainelFundo;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbt_ok;
    private javax.swing.JButton jbt_pesquisar;
    private javax.swing.JButton jbt_sair;
    private javax.swing.JTable jtb_pesquisa;
    private controle.JUpperField jtf_pesquisa;
    // End of variables declaration//GEN-END:variables
}
