/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ControleUniversal;
import controle.formata_janelas;
import controle.obter_arquivo_conf;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author Lindembergue Pereira - LP-INFORMATICA - lindembergue.pereira@hotmail.com
 */
public class FormLogin extends javax.swing.JFrame {
    
    
//declara importações;
    ConectaBanco condb = new ConectaBanco();
    obter_arquivo_conf o_ac = new obter_arquivo_conf();
    formata_janelas f_visual = new formata_janelas();
    ControleUniversal ctrl_uni = new ControleUniversal();

//declara variaveis privadas;
    private String login, senha, nome;
    private int permissao;
    
//declara variaveis internas;
    String Serial, SerialD, DataIni, DataVenc, DataTemp, DataRenova, DataConvertidaString, chavedesbloqueio,DataHoje, AgoraHora;
    int Licenciado, TempoTesteRestante;
    java.sql.Date DataAnteriorTeste, DataInicialTeste;

//variaveis nao utilizadas (revisar);    
//    String Nome, tipoUser, Login, Senha;
//    Date vDataV, vDataR,vDataH;
//    long ChaveBloqueio, ChaveDesBloqueio, dtB, dtH;
    
    
    
    /**
     * Creates new form FormLogar
     */
    public FormLogin() throws IOException {
        
        initComponents();
        jLabelinfo.setVisible(false);
        getRootPane().setDefaultButton(jButtonLogar);
        BuscaUsuarios();
        f_visual.aplicavisual();
        jPasswordFieldSenha.grabFocus();

        try {
                     
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
                            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FormLogin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(FormLogin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(FormLogin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(FormLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
                          
    }    
    

    
    
public void BuscaUsuarios() throws IOException{
    
    condb.conecta();
    try {
            condb.executaSQL("select * from usuarios order by login");
            condb.rs.first();
            jComboBoxUser.removeAllItems();
            //jComboBoxUser.addItem("Selecione uma Categoria");
            do{
                jComboBoxUser.addItem(condb.rs.getString("login"));
            } while (condb.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Usuários. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Usuários.");
        }
    condb.desconecta();
    jPasswordFieldSenha.grabFocus();
}

    public void ObtemDadosLicenciamento(){
        condb.conecta();
        condb.executaSQL("select * from licenciamento where codigo=1");
        try {
            if (condb.rs.first()){
                Serial = condb.rs.getString("serial");
                DataIni = condb.rs.getString("datainst");
                DataVenc = condb.rs.getString("datavenc");
                DataRenova = condb.rs.getString("datarenova");
                chavedesbloqueio = condb.rs.getString("chavedesbloqueio");
                DataInicialTeste = condb.rs.getDate("data_i_teste");
                Licenciado = condb.rs.getInt("licenciado");
                TempoTesteRestante = condb.rs.getInt("tempo_restante_teste");
                DataAnteriorTeste = condb.rs.getDate("data_a_teste");
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        condb.desconecta();
        ValidaLicenciamento();
    }
    
    public void ValidaLicenciamento(){
        if (chavedesbloqueio==null||chavedesbloqueio.equals("")){
            FormLicenciamento FrmLic = new FormLicenciamento();
            FrmLic.nome = nome;
            FrmLic.senha = senha;
            FrmLic.permissao = permissao;
            Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
            FrmLic.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"icone_16x16.png"));
            FrmLic.setVisible(true);
            dispose();
        }else{
            
            AbreFormPrincipal();
            
        }
    }
    
    
    
    public void AbreFormPrincipal(){
                    FormPrincipal fp = new FormPrincipal();
                    fp.ObterUsuarioSenha(nome, senha, permissao);
                    fp.setExtendedState(MAXIMIZED_BOTH);
//                    fp.setResizable(false);
                    f_visual.AbreNovaJanela(fp);
                    dispose();
                    
    }
    
     
     
            

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jComboBoxUser = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jPasswordFieldSenha = new javax.swing.JPasswordField();
        jButtonLogar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jLabelinfo = new javax.swing.JLabel();
        jLabelImg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Logar");
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                saindo(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                AoAbrir(evt);
            }
        });
        getContentPane().setLayout(null);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Login:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(200, 170, 60, 30);

        jComboBoxUser.setEditable(true);
        jComboBoxUser.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jComboBoxUser.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.SystemColor.activeCaptionBorder));
        jComboBoxUser.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxUserItemStateChanged(evt);
            }
        });
        jComboBoxUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxUserActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBoxUser);
        jComboBoxUser.setBounds(260, 170, 220, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Senha:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(200, 210, 60, 30);

        jPasswordFieldSenha.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.SystemColor.activeCaptionBorder));
        jPasswordFieldSenha.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jPasswordFieldSenha.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPasswordFieldSenhaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPasswordFieldSenhaFocusLost(evt);
            }
        });
        jPasswordFieldSenha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jPasswordFieldSenhaKeyTyped(evt);
            }
        });
        getContentPane().add(jPasswordFieldSenha);
        jPasswordFieldSenha.setBounds(260, 210, 220, 30);

        jButtonLogar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jButtonLogar.setText("Logar");
        jButtonLogar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLogarActionPerformed(evt);
            }
        });
        jButtonLogar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonLogarKeyPressed(evt);
            }
        });
        getContentPane().add(jButtonLogar);
        jButtonLogar.setBounds(280, 300, 100, 40);

        jButtonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonCancelar.setText("Sair");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCancelar);
        jButtonCancelar.setBounds(380, 300, 100, 40);

        jLabelinfo.setForeground(new java.awt.Color(255, 255, 255));
        jLabelinfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelinfo.setText("jLabel2");
        getContentPane().add(jLabelinfo);
        jLabelinfo.setBounds(200, 240, 280, 25);

        jLabelImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/fundo_login.png"))); // NOI18N
        getContentPane().add(jLabelImg);
        jLabelImg.setBounds(0, 0, 510, 370);

        setSize(new java.awt.Dimension(514, 398));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonLogarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLogarActionPerformed

        login = (String) jComboBoxUser.getSelectedItem();
        senha = jPasswordFieldSenha.getText();
        
        try {
            
            if (login.equals("")&&(senha.equals(""))) {
                JOptionPane.showMessageDialog(rootPane, "Campos em branco, não são aceitos.");
            } else {
                condb.conecta();
                condb.executaSQL("select * from usuarios where login='"+login+"'");
                                
                if (condb.rs.first()){
                    
                    nome = condb.rs.getString("nome");
                    permissao = condb.rs.getInt("permissao");
                
                }else{
                    
                    JOptionPane.showMessageDialog(rootPane, "Usuário inválido!");
                    jPasswordFieldSenha.setText("");
                    jComboBoxUser.grabFocus();
                }
                            
                if (condb.rs.getString("senha").equals(senha)){
                    
//                    ObtemDadosLicenciamento();
                        AbreFormPrincipal();
                    
                } else{
                    
                    JOptionPane.showMessageDialog(rootPane, "Senha inválida!");
                    jPasswordFieldSenha.grabFocus();
                    jPasswordFieldSenha.setText("");
                    
                }
                
                condb.desconecta();
            }//                Logger.getLogger(Logar.class.getName()).log(Level.SEVERE, null, ex);
            
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane, "Erro: "+ex);
        }


    }//GEN-LAST:event_jButtonLogarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonLogarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButtonLogarKeyPressed

    }//GEN-LAST:event_jButtonLogarKeyPressed

    private void jComboBoxUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxUserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxUserActionPerformed

    private void jPasswordFieldSenhaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordFieldSenhaFocusGained
   Toolkit tk = Toolkit.getDefaultToolkit();    
    
    if(tk.getLockingKeyState(KeyEvent.VK_CAPS_LOCK)){
        
        jLabelinfo.setText("Caps Lock está ativada");
        jLabelinfo.setVisible(true);
        
    }else{
        
        jLabelinfo.setText("");
        jLabelinfo.setVisible(false);
        
    }
//        JOptionPane.showMessageDialog(rootPane, "Caps Lock está ativada");
      //System.out.println("Caps Lock está ativada");         // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordFieldSenhaFocusGained

    private void jPasswordFieldSenhaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPasswordFieldSenhaFocusLost

            Toolkit tk = Toolkit.getDefaultToolkit();    
    
    if(tk.getLockingKeyState(KeyEvent.VK_CAPS_LOCK)){
        
        jLabelinfo.setText("Caps Lock está ativada");
        jLabelinfo.setVisible(true);
        
    }else{
        
        jLabelinfo.setText("");
        jLabelinfo.setVisible(false);
        
    }
    
    }//GEN-LAST:event_jPasswordFieldSenhaFocusLost

    private void jPasswordFieldSenhaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jPasswordFieldSenhaKeyTyped
    Toolkit tk = Toolkit.getDefaultToolkit();    
    
    if(tk.getLockingKeyState(KeyEvent.VK_CAPS_LOCK)){
        
        jLabelinfo.setText("Caps Lock está ativada");
        jLabelinfo.setVisible(true);
        
    }else{
        
        jLabelinfo.setText("");
        jLabelinfo.setVisible(false);
        
    }
    
    }//GEN-LAST:event_jPasswordFieldSenhaKeyTyped

    private void saindo(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_saindo
        System.exit(0);
    }//GEN-LAST:event_saindo

    private void jComboBoxUserItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxUserItemStateChanged
        jPasswordFieldSenha.grabFocus();
    }//GEN-LAST:event_jComboBoxUserItemStateChanged

    private void AoAbrir(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_AoAbrir
        jPasswordFieldSenha.grabFocus();
    }//GEN-LAST:event_AoAbrir

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
     
    
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new FormLogin().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(FormLogin.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonLogar;
    private javax.swing.JComboBox jComboBoxUser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelImg;
    private javax.swing.JLabel jLabelinfo;
    private javax.swing.JPasswordField jPasswordFieldSenha;
    // End of variables declaration//GEN-END:variables
}
