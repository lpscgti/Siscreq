/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package visual;

import controle.ConectaBanco;
import controle.ControleTipoUnd;
import controle.ValidaPermissaoUsuario;
import controle.formata_janelas;
import controle.plano_fundo_forms;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.beans.PropertyVetoException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import modelo.ModeloTabela;
import modelo.ModeloTipoUnd;

/**
 *
 * @author linde
 */
public class FormTipoUnd extends javax.swing.JInternalFrame {

    //Declara importações:
    ConectaBanco c_db = new ConectaBanco();
    ControleTipoUnd ctrl_tipo = new ControleTipoUnd();
    ModeloTipoUnd mod_tipo = new ModeloTipoUnd();
    formata_janelas visual_form = new formata_janelas();
    ValidaPermissaoUsuario valida_peruser = new ValidaPermissaoUsuario();
    
    //declara variáveis:
    String sql = "";
    String dt_form_pesq = "";
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    int idSel = 0;
    int cod_tipo;
    boolean novo_cad = false;
    java.sql.Date Data;
    String mensagem;
    java.sql.Date DataConvertidaSQL;
    public boolean a_form_ex = false;
    public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.
    
    /**
     * Creates new form FormTipoUnd
     */
    public FormTipoUnd() {
        initComponents();
        ColocaImagemFundoFrame();
        IniciaComp();
        LimpaItens();
        Pesquisaini();
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        PainelFundo.setBorder(new plano_fundo_forms(AlturaForm, LarguraForm));
    }
    
    public void IniciaComp(){
        jtf_codigo.setEditable(false);
        jbt_novo.setEnabled(true);
        jbt_editar.setEnabled(false);
        jbt_excluir.setEnabled(false);
        jbt_salvar.setEnabled(false);
        jbt_sair.setEnabled(true);
    }
    
    public void LimpaItens(){
        jtf_codigo.setText("");
        jtf_tipo.setText("");
    }
    
    public void DesativaItens(){
        jtf_codigo.setEnabled(false);
        jtf_tipo.setEnabled(false);
    }
    
    public void AtivaItens(){
        jtf_codigo.setEnabled(true);
        jtf_tipo.setEnabled(true);
    }
    
    public void Pesquisaini(){
        sql = "select * from tipo_und order by tipo";
        preencherTabela(sql);
    }
    
    public void preencherTabela(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Tipo","<html><center>Data<br>Cadastro</html>","<html><center>Cadastrado<br>Por</html>",
            "<html><center>Data<br>Modificação</html>", "<html><center>Modificado<br>Por</html>" }; //18 Campos
        c_db.conecta();
        c_db.executaSQL(SQL);
        
        String dt_cad="", dt_mod="";
        
        
        try {
            if(c_db.rs.first()){
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            
            do{
                
                if (c_db.rs.getDate("data_cad")!=null){dt_cad = df.format(c_db.rs.getDate("data_cad"));}
                if (c_db.rs.getDate("data_mod")!=null){dt_cad = df.format(c_db.rs.getDate("data_mod"));}
                
                dados.add(new Object[]{c_db.rs.getString("codigo"),                 //0 60
                                        c_db.rs.getString("tipo"),                  //1 100
                                        dt_cad,                                               //2 80
                                        c_db.rs.getString("cad_por"),               //3 100
                                        dt_mod,                                               //4 80
                                        c_db.rs.getString("mod_por"),               //5 100
                });
            }while(c_db.rs.next());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada. \n"
                    + "Erro: "+ex);
        }
        
        ModeloTabela m_tb = new ModeloTabela(dados, Colunas);
        jtb_listagem.setModel(m_tb);
        DefaultTableCellRenderer ali_D = new DefaultTableCellRenderer();
        ali_D.setHorizontalAlignment(SwingConstants.RIGHT);
        DefaultTableCellRenderer ali_C = new DefaultTableCellRenderer();
        ali_C.setHorizontalAlignment(SwingConstants.CENTER);
        jtb_listagem.getTableHeader().setPreferredSize(new Dimension(2920, 40));
        jtb_listagem.getColumnModel().getColumn(0).setPreferredWidth(60);
        jtb_listagem.getColumnModel().getColumn(0).setCellRenderer(ali_D);
        jtb_listagem.getColumnModel().getColumn(0).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(1).setPreferredWidth(100);
        jtb_listagem.getColumnModel().getColumn(1).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(2).setPreferredWidth(80);
        jtb_listagem.getColumnModel().getColumn(2).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(3).setPreferredWidth(100);
        jtb_listagem.getColumnModel().getColumn(3).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(4).setPreferredWidth(80);
        jtb_listagem.getColumnModel().getColumn(4).setResizable(false);
        jtb_listagem.getColumnModel().getColumn(5).setPreferredWidth(100);
        jtb_listagem.getColumnModel().getColumn(5).setResizable(false);
        jtb_listagem.getTableHeader().setReorderingAllowed(false);
        jtb_listagem.setAutoResizeMode(jtb_listagem.AUTO_RESIZE_OFF);
        jtb_listagem.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        c_db.desconecta();
    }
    
    public void obtemformatodata (String Data){
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        dt_form_pesq = ano+"-"+mes+"-"+dia+" 00:00:00";
    }
    
    public void ValidaCampos(){
        if (jtf_tipo.getText().length()<=1){
            JOptionPane.showMessageDialog(null, "Campo nome não pode estar vazio, ou deve ser\npreenchido corretamente!\nPor favor digite o nome corretamente,\ntolerável 1 carectere.");
            jtf_tipo.requestFocus();
            return;
        }
    }
    
    public void SalvaRegistro(){
        ValidaCampos();
        mod_tipo.setCodigo(cod_tipo);
        mod_tipo.setTipo(jtf_tipo.getText());
        if (ctrl_tipo.SalvaRegistro(mod_tipo, novo_cad)){
            mensagem = "Registro Salvo com sucesso.";
            LimpaItens();
            DesativaItens();
            jbt_novo.setEnabled(true);
            jbt_salvar.setEnabled(false);
            Pesquisaini();
        }else{
            mensagem = "Houve um erro ao salvar o registro. \nDados técnicos do erro: "+ctrl_tipo.menssagem_erro;
        }
        JOptionPane.showMessageDialog(null, mensagem);
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PainelFundo = new javax.swing.JPanel();
        jtf_codigo = new controle.JUpperField();
        jtf_tipo = new controle.JUpperField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtb_listagem = new javax.swing.JTable();
        jbt_sair = new javax.swing.JButton();
        jbt_excluir = new javax.swing.JButton();
        jbt_salvar = new javax.swing.JButton();
        jbt_editar = new javax.swing.JButton();
        jbt_novo = new javax.swing.JButton();

        setIconifiable(true);
        setTitle("CADASTRO E LISTAGEM DE UNIDADES DE MEDIDA");
        getContentPane().setLayout(null);

        PainelFundo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PainelFundo.setLayout(null);
        PainelFundo.add(jtf_codigo);
        jtf_codigo.setBounds(10, 30, 80, 25);
        PainelFundo.add(jtf_tipo);
        jtf_tipo.setBounds(100, 30, 230, 25);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Código:");
        PainelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 80, 20);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Tipo:");
        PainelFundo.add(jLabel2);
        jLabel2.setBounds(100, 10, 230, 20);

        jtb_listagem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jtb_listagem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtb_listagemMouseClicked(evt);
            }
        });
        jtb_listagem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtb_listagemKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jtb_listagem);

        PainelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 60, 320, 210);

        getContentPane().add(PainelFundo);
        PainelFundo.setBounds(0, 0, 350, 280);

        jbt_sair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/exit_PNG36.png"))); // NOI18N
        jbt_sair.setToolTipText("Sair");
        jbt_sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_sairActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_sair);
        jbt_sair.setBounds(280, 290, 50, 40);

        jbt_excluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/remove.png"))); // NOI18N
        jbt_excluir.setToolTipText("Remover Registro");
        jbt_excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_excluirActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_excluir);
        jbt_excluir.setBounds(230, 290, 50, 40);

        jbt_salvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/accept.png"))); // NOI18N
        jbt_salvar.setToolTipText("Salvar Registro");
        jbt_salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_salvarActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_salvar);
        jbt_salvar.setBounds(180, 290, 50, 40);

        jbt_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/editResultado.png"))); // NOI18N
        jbt_editar.setToolTipText("Editar Registro");
        jbt_editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_editarActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_editar);
        jbt_editar.setBounds(130, 290, 50, 40);

        jbt_novo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/24x24/add.png"))); // NOI18N
        jbt_novo.setToolTipText("Novo Registro");
        jbt_novo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_novoActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_novo);
        jbt_novo.setBounds(80, 290, 50, 40);

        setBounds(0, 0, 352, 371);
    }// </editor-fold>//GEN-END:initComponents

    private void jbt_sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_sairActionPerformed
        // TODO add your handling code here:
        if (a_form_ex==true){
            try {
                jifr.setIcon(false);
            } catch (PropertyVetoException ex) {
                
            }
        }
        this.dispose();
        FormPrincipal.AreaDeTrabalhoPrincipal.remove(this);
    }//GEN-LAST:event_jbt_sairActionPerformed

    private void jtb_listagemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtb_listagemMouseClicked
        // TODO add your handling code here:
        String sID = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 0));
        String sTipo = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 1));
        cod_tipo = Integer.parseInt(sID);
        jtf_codigo.setText(sID);
        jtf_tipo.setText(sTipo);
        jbt_editar.setEnabled(true);
    }//GEN-LAST:event_jtb_listagemMouseClicked

    private void jtb_listagemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtb_listagemKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode()==KeyEvent.VK_UP || evt.getKeyCode()==KeyEvent.VK_DOWN){
            String sID = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 0));
            String stipo = ("" + jtb_listagem.getValueAt(jtb_listagem.getSelectedRow(), 1));
            cod_tipo = Integer.parseInt(sID);
            jtf_codigo.setText(sID);
            jtf_tipo.setText(stipo);
            jbt_editar.setEnabled(true);
        }else if(evt.getKeyCode()==KeyEvent.VK_ENTER){

        }
    }//GEN-LAST:event_jtb_listagemKeyReleased

    private void jbt_novoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_novoActionPerformed
        // TODO add your handling code here:
         if (valida_peruser.ValidaPermissao("salvar")){
            LimpaItens();
            ctrl_tipo.NovoRegistro();
            cod_tipo = ctrl_tipo.Cod_tipo;
            novo_cad = ctrl_tipo.novo_cad;
            Data = ctrl_tipo.Dagora;
            jtf_codigo.setText(String.valueOf(cod_tipo));
            jbt_novo.setEnabled(false);
            jbt_editar.setEnabled(false);
            jbt_excluir.setEnabled(false);
            jbt_salvar.setEnabled(true);
            AtivaItens();
            jtf_tipo.requestFocus();
        }else{
            
        }
    }//GEN-LAST:event_jbt_novoActionPerformed

    private void jbt_editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_editarActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            AtivaItens();
            jbt_salvar.setEnabled(true);
            jbt_excluir.setEnabled(true);
            jbt_editar.setEnabled(false);
            jtf_tipo.requestFocus();
        }else{
             
        }
    }//GEN-LAST:event_jbt_editarActionPerformed

    private void jbt_salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_salvarActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("salvar")){
            SalvaRegistro();
        }else{
        }
    }//GEN-LAST:event_jbt_salvarActionPerformed

    private void jbt_excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_excluirActionPerformed
        // TODO add your handling code here:
        if (valida_peruser.ValidaPermissao("excluir")){
            int i = JOptionPane.showConfirmDialog(null, "Deseja realizar a exclusão?.","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                    mod_tipo.setCodigo(cod_tipo);
                    ctrl_tipo.ExcluiRegistro(mod_tipo);
                    Pesquisaini();
                    LimpaItens();
                    DesativaItens();
                    jbt_editar.setEnabled(false);
                    jbt_salvar.setEnabled(false);
                    jbt_excluir.setEnabled(false);
                    }
        }else{
  
        }
    }//GEN-LAST:event_jbt_excluirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PainelFundo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbt_editar;
    private javax.swing.JButton jbt_excluir;
    private javax.swing.JButton jbt_novo;
    private javax.swing.JButton jbt_sair;
    private javax.swing.JButton jbt_salvar;
    private javax.swing.JTable jtb_listagem;
    private controle.JUpperField jtf_codigo;
    private controle.JUpperField jtf_tipo;
    // End of variables declaration//GEN-END:variables
}
