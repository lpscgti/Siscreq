/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package siscreq;

import controle.ControleUniversal;
import controle.formata_janelas;
import java.awt.Toolkit;
import java.io.IOException;
import java.net.ServerSocket;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.JOptionPane;
import visual.FormLogin;


/**
 *
 * @author linde
 */
public class Siscreq {
//    declara importações;
    static formata_janelas f_visual = new formata_janelas();
//    declara variaveis de inicio;
    private static ServerSocket s;
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
         f_visual.aplicavisual();
         ControleUniversal ctrl_uni = new ControleUniversal();
        try {
            
            if (s==null){
            s = new ServerSocket(9193);
                FormLogin FrmLogin = new FormLogin();
//                ctrl_uni.ColocaIconeJFrame(FrmLogin);
                Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
                FrmLogin.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"icone_16x16.png"));
                FrmLogin.setVisible(true);
                f_visual.AbreNovaJanela(FrmLogin);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Desculpe, mas o Siscreq+  já está Aberto.");
        }
        
    }
    
}
